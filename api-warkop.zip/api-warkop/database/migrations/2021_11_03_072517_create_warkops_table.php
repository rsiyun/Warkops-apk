<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWarkopsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('warkops', function (Blueprint $table) {
            $table->increments('idwarkop');
            $table->string('username');
            $table->string('namapengguna');
            $table->string('namawarung');
            $table->string('email');
            $table->string('password');
            $table->decimal('longtitude', 11, 8);
            $table->decimal('latitude', 10, 8);
            $table->string('alamat');
            $table->string('notelp', 50);
            $table->string('imgwarkop');
            $table->float('rating');
            $table->integer('action');
            $table->string('api_token');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('warkops');
    }
}
