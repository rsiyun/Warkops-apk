<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pelanggan extends Model
{
    protected $primaryKey = 'idpelanggan';
    protected $fillable = ['username', 'namapengguna', 'password', 'alamat', 'longtitude', 'latitude', 'notelp', 'email', 'imgpelanggan', 'action', 'api_token'];
}
