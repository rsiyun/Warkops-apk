<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kategori extends Model
{
    //kolom mana yang boleh di edit/diisi 
    protected $primaryKey = 'idkategori';
    protected $fillable = ['idwarkop', 'kategori'];
}
