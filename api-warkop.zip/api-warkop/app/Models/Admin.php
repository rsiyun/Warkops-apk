<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    //
    protected $primaryKey = 'idadmin';
    protected $fillable = ['username', 'password', 'api_token'];
}
