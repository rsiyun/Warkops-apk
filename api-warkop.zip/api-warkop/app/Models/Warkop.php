<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Warkop extends Model
{
    protected $primaryKey = 'idwarkop';
    protected $fillable = [
        'username', 'namapengguna', 'namawarung', 'email', 'password', 'longtitude', 'latitude',
        'alamat', 'notelp', 'imgwarkop', 'rating', 'action', 'api_token'
    ];
}
