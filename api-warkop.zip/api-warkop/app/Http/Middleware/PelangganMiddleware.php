<?php

namespace App\Http\Middleware;

use Closure;

class PelangganMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->user <> 'pelanggan') {
            return redirect('loginpelanggan');
        }
        return $next($request);
    }
}
