<?php

namespace App\Http\Controllers;

use App\Models\Detail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Detail::all();
        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'idorder' => 'required',
            'idmenu' => 'required',
            'jumlah' => 'required',
            'hargajual' => 'required',
        ]);
        $detail = Detail::create($request->all());
        if ($detail) {
            return response()->json([
                'message' => 'Data sudah disimpan',
                'data' => $detail
            ]);
        } else {
            return response()->json([
                'message' => 'Data gagal disimpan',
                'data' => ''
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Detail  $detail
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = DB::table('details')
            ->join('orders', 'orders.idorder', '=', 'details.idorder')
            ->join('menus', 'menus.idmenu', '=', 'details.idmenu')
            ->where('orders.idorder', $id)
            ->select('details.*', 'orders.*', 'menus.menu', 'menus.harga', 'menus.imgmenu')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'ini data tampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'ini data tampilkan',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Detail  $detail
     * @return \Illuminate\Http\Response
     */
    public function edit(Detail $detail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Detail  $detail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Detail $detail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Detail  $detail
     * @return \Illuminate\Http\Response
     */
    public function destroy(Detail $detail)
    {
        //
    }
}
