<?php

namespace App\Http\Controllers;

use App\Models\order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->orderByDesc('idorder')
            ->select('orders.*', 'pelanggans.username', 'warkops.namawarung')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'idwarkop' => 'required',
            'idpelanggan' => 'required',
            'tglorder' => 'required',
            'status' => 'required',
            'total' => 'required'
        ]);
        $order = Order::create($request->all());
        if ($order) {
            return response()->json([
                'message' => 'Data sudah disimpan',
                'data' => $order
            ]);
        } else {
            return response()->json([
                'message' => 'Data gagal disimpan',
                'data' => ''
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\order  $order
     * @return \Illuminate\Http\Response
     */

    public function show2($id)
    {
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->where('orders.idpelanggan', $id)
            ->where('orders.status', '=', 3)
            ->select('orders.*', 'pelanggans.username', 'warkops.namawarung', 'warkops.notelp', 'warkops.rating', 'warkops.imgwarkop')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }
    public function untukDetail($id)
    {
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->where('orders.idpelanggan', $id)
            ->where('orders.status', '<', 3)
            ->orderByDesc('idorder')
            ->select('orders.*', 'pelanggans.username', 'warkops.namawarung', 'warkops.notelp', 'warkops.rating', 'warkops.imgwarkop')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }
    public function show($id)
    {
        //
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->where('orders.idpelanggan', $id)
            ->where('orders.status', '<', 3)
            ->select('orders.*', 'pelanggans.username', 'warkops.namawarung', 'warkops.notelp', 'warkops.rating', 'warkops.imgwarkop')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }
    public function show3($id)
    {
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->where('orders.idwarkop', $id)
            ->where('orders.status', '<', 3)
            ->select('orders.*', 'pelanggans.username', 'pelanggans.alamat', 'pelanggans.notelp', 'pelanggans.imgpelanggan')
            ->get();
        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }
    public function show4($id)
    {
        $data = DB::table('orders')
            ->join('pelanggans', 'pelanggans.idpelanggan', '=', 'orders.idpelanggan')
            ->join('warkops', 'warkops.idwarkop', '=', 'orders.idwarkop')
            ->where('orders.idwarkop', $id)
            ->where('orders.status', '=', 3)
            ->select('orders.*', 'pelanggans.username', 'pelanggans.alamat', 'pelanggans.notelp', 'pelanggans.imgpelanggan')
            ->get();
        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampilkan',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampilkan',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'idwarkop' => 'required',
            'idpelanggan' => 'required',
            'tglorder' => 'required',
            'status' => 'required',
            'total' => 'required'
        ]);
        $order = Order::where('idorder', $id)->update($request->all());
        $tampil = Order::where('idorder', $id)->get();
        if ($order) {
            return response()->json([
                'success' => true,
                'message' => 'melanjutkan status',
                'data' => $tampil,
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'gagal melanjutkan status',
                'data' => '',
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(order $order)
    {
        //
    }
}
