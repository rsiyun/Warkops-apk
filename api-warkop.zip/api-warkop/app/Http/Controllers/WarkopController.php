<?php

namespace App\Http\Controllers;

use App\Models\Warkop;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class WarkopController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = Warkop::where('action', 1)->get();
        if ($data) {
            return response()->json([
                'message' => 'ada data',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'message' => 'tidak data',
                'data' => '',
            ]);
        }
    }

    public function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');

        $warkop = Warkop::where('username', $username)->first();
        if (Hash::check($password, $warkop->password)) {
            // $token = Str::random(40);
            // $warkop->update([
            //     'api_token' => $token
            // ]);
            return response()->json($warkop);
        } else {
            return response()->json('');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'username' => 'required | unique:warkops',
            'namapengguna' => 'required',
            'namawarung' => 'required',
            'email' => 'required',
            'password' => 'required',
            'longtitude' => 'required',
            'latitude' => 'required',
            'alamat' => 'required',
            'notelp' => 'required',
            'imgwarkop' => 'required'
        ]);
        $gambar = $request->file('imgwarkop')->getClientOriginalName();
        $request->file('imgwarkop')->move('upload/imgwarkop', $gambar);
        $token = Str::random(40);
        $data = [
            'username' => $request->input('username'),
            'namapengguna' => $request->input('namapengguna'),
            'namawarung' => $request->input('namawarung'),
            'email' => $request->input('email'),
            'password' => Hash::make($request->input('password')),
            'longtitude' => $request->input('longtitude'),
            'latitude' => $request->input('latitude'),
            'alamat' => $request->input('alamat'),
            'notelp' => $request->input('notelp'),
            'imgwarkop' => url('upload/imgwarkop/' . $gambar),
            'rating' => $request->input('rating'),
            'api_token' => $token,
            'action' => 1
        ];
        $warkop = Warkop::create($data);
        if ($warkop) {
            return response()->json([
                'success' => true,
                'message' => 'Register Success!',
                'data' => $warkop
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Register Fail!',
                'data' => ''
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Warkop  $warkop
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $data = Warkop::where('idwarkop', $id)->get();
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Warkop  $warkop
     * @return \Illuminate\Http\Response
     */
    public function edit(Warkop $warkop)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Warkop  $warkop
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // $this->validate($request, [
        //     'username' => 'required',
        //     'namapengguna' => 'required',
        //     'namawarung' => 'required',
        //     'email' => 'required',
        //     'password' => 'required',
        //     'longtitude' => 'required',
        //     'latitude' => 'required',
        //     'alamat' => 'required',
        //     'notelp' => 'required',
        //     'imgwarkop' => 'required'
        // ]);
        if ($request->hasFile('imgwarkop')) {
            $gambar = $request->file('imgwarkop')->getClientOriginalName();
            $request->file('imgwarkop')->move('upload/imgwarkop', $gambar);
            $token = Str::random(40);
            $data = [
                'username' => $request->input('username'),
                'namapengguna' => $request->input('namapengguna'),
                'namawarung' => $request->input('namawarung'),
                'email' => $request->input('email'),
                'password' => Hash::make($request->input('password')),
                'longtitude' => $request->input('longtitude'),
                'latitude' => $request->input('latitude'),
                'alamat' => $request->input('alamat'),
                'notelp' => $request->input('notelp'),
                'imgwarkop' => url('upload/imgwarkop/' . $gambar),
                'rating' => $request->input('rating'),
                'api_token' => $token,
                'action' => $request->input('action')
            ];
        } else {
            $token = Str::random(40);
            $data = [
                'username' => $request->input('username'),
                'namapengguna' => $request->input('namapengguna'),
                'namawarung' => $request->input('namawarung'),
                'email' => $request->input('email'),
                'password' => Hash::make($request->input('password')),
                'longtitude' => $request->input('longtitude'),
                'latitude' => $request->input('latitude'),
                'alamat' => $request->input('alamat'),
                'notelp' => $request->input('notelp'),
                'rating' => $request->input('rating'),
                'api_token' => $token,
                'action' => 1
            ];
        }
        $warkop = Warkop::where('idwarkop', $id)->update($data);
        $tampil = Warkop::where('idwarkop', $id)->get();
        if ($warkop) {
            return response()->json([
                'success' => true,
                'message' => 'data berhasil diubah !',
                'data' => $tampil
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'data gagal diubah !',
                'data' => ''
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Warkop  $warkop
     * @return \Illuminate\Http\Response
     */
    public function destroy(Warkop $warkop)
    {
        //
    }
}
