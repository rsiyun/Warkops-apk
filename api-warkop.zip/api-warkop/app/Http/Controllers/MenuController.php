<?php

namespace App\Http\Controllers;

use App\Models\menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = Menu::all();
        if ($data) {
            return response()->json([
                'message' => 'data berhasil diambil',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal diambil',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'idkategori' => 'required',
            'menu' => 'required',
            'deskripsi' => 'required',
            // 'imgmenu' => 'required',
            'harga' => 'required | numeric',
            'status' => 'required | numeric'
        ]);

        // $gambar = $request->file('imgmenu')->getClientOriginalName();
        // $request->file('imgmenu')->move('upload/imgmenu', $gambar);
        $data = [
            'idkategori' => $request->input('idkategori'),
            'menu' => $request->input('menu'),
            'deskripsi' => $request->input('deskripsi'),
            // 'imgmenu' => url('upload/imgmenu' . $gambar),
            'harga' => $request->input('harga'),
            'status' => $request->input('status')
        ];

        $menu = Menu::create($data);
        // if ($menu) {
        //     return response()->json([
        //         'success' => true,
        //         'message' => 'data berhasil diubah'
        //     ]);
        // } else {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'data gagal diubah'
        //     ]);
        // }

        return response()->json($menu);
    }
    public function gambar(Request $request, $id)
    {
        $gambar = $request->file('imgmenu')->getClientOriginalName();
        $request->file('imgmenu')->move('upload/imgmenu/', $gambar);
        $data = [
            'imgmenu' => url('upload/imgmenu/' . $gambar),
        ];
        $menu = Menu::where('idmenu', $id)->update($data);
        if ($menu) {
            return response()->json([
                'success' => true,
                'message' => 'data berhasil diubah'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'message' => 'data gagal diubah'
            ]);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $data = DB::table('menus')
            ->join('kategoris', 'kategoris.idkategori', '=', 'menus.idkategori')
            ->join('warkops', 'warkops.idwarkop', '=', 'kategoris.idwarkop')
            ->where('kategoris.idwarkop', $id)
            ->select('menus.*', 'kategoris.*')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampil',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampil',
                'data' => ''
            ]);
        }
    }
    public function untukCart($id, $id2)
    {
        //
        $data = DB::table('menus')
            ->join('kategoris', 'kategoris.idkategori', '=', 'menus.idkategori')
            ->join('warkops', 'warkops.idwarkop', '=', 'kategoris.idwarkop')
            ->where('warkops.idwarkop', $id)
            ->where('menus.idmenu', $id2)
            ->select('menus.*', 'warkops.namawarung')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'data berhasil ditampil',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditampil',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function edit(menu $menu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'idkategori' => 'required',
            'menu' => 'required',
            'imgmenu' => 'required',
            'harga' => 'required | numeric',
            'status' => 'required | numeric'
        ]);

        if ($request->hasFile('imgmenu')) {
            $gambar = $request->file('imgmenu')->getClientOriginalName();
            $request->file('imgmenu')->move('upload/imgmenu', $gambar);
            $data = [
                'idkategori' => $request->input('idkategori'),
                'menu' => $request->input('menu'),
                'imgmenu' => url('upload/imgmenu' . $gambar),
                'harga' => $request->input('harga'),
                'status' => $request->input('status')
            ];
        } else {
            $data = [
                'idkategori' => $request->input('idkategori'),
                'menu' => $request->input('menu'),
                'harga' => $request->input('harga'),
                'status' => $request->input('status')
            ];
        }
        $menu = Menu::where('idmenu', $id)->update($data);
        $tampil = Menu::where('idmenu', $id)->get();
        if ($menu) {
            return response()->json([
                'success' => true,
                'data' => $tampil,
                'message' => 'data berhasil diubah'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'data' => '',
                'message' => 'data gagal diubah'
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\menu  $menu
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $menu = Menu::where('idmenu', $id)->delete();
        if ($menu) {
            return response()->json([
                'message' => 'data berhasil dihapus'
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal dihapus'
            ]);
        }
    }
}
