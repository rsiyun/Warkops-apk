<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class PelangganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        //
        $data = Pelanggan::all();
        if ($data) {
            return response()->json([
                'message' => 'berhasil diambil',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'gagal diambil',
                'data' => ''
            ]);
        }
    }

    public function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');

        $pelanggan = Pelanggan::where('username', $username)->first();
        if (Hash::check($password, $pelanggan->password)) {
            // $token = Str::random(40);
            // $pelanggan->update([
            //     'api_token' => $token
            // ]);
            if ($pelanggan) {
                return response()->json($pelanggan);
            } else {
                return response()->json('');
            }
        }
    }
    public function showLp(Request $request)
    {
        $username = $request->input('username');
        $pelanggan = Pelanggan::where('username', $username)->first();
        if ($pelanggan) {
            return response()->json($pelanggan);
        } else {
            return response()->json([
                "username" => null
            ]);
        }
    }
    public function LupaPassword(Request $request, $id)
    {
        $data = [
            'password' => Hash::make($request->input('password'))
        ];
        $pelanggan = Pelanggan::where('idpelanggan', $id)->update($data);
        if ($pelanggan) {
            return response()->json([
                'message' => 'Ganti Password Success!',
                'data' => $pelanggan
            ]);
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'username' => 'required | unique:pelanggans',
            'namapengguna' => 'required',
            'notelp' => 'required',
            'password' => 'required',
            // 'imgpelanggan' => 'required',
        ]);
        $token = Str::random(40);
        $data = [
            'username' => $request->input('username'),
            'namapengguna' => $request->input('namapengguna'),
            'notelp' => $request->input('notelp'),
            'password' => Hash::make($request->input('password')),
            'imgpelanggan' => url('upload/imgpelanggan/profiledefault.jpg'),
            'alamat' => "",
            'longtitude' => 0,
            'latitude' => 0,
            'action' => 1,
            'api_token' => $token
        ];
        $pelanggan = Pelanggan::create($data);
        if ($pelanggan) {
            return response()->json([
                'message' => 'Register Success!',
                'data' => $pelanggan
            ]);
        } else {
            return response()->json([
                'message' => 'Register Fail!',
                'data' => ''
            ]);
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Pelanggan::where('idpelanggan', $id)->get();
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function edit(Pelanggan $pelanggan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'username' => 'required | unique:pelanggans',
            'namapengguna' => 'required',
            'notelp' => 'required',
            'password' => 'required',
            'imgpelanggan' => 'required',
        ]);
        if ($request->hasFile('imgpelanggan')) {
            $gambar = $request->file('imgpelanggan')->getClientOriginalName();
            $request->file('imgpelanggan')->move('upload/imgpelanggan', $gambar);
            $token = Str::random(40);
            $data = [
                'username' => $request->input('username'),
                'namapengguna' => $request->input('namapengguna'),
                'notelp' => $request->input('notelp'),
                'password' => Hash::make($request->input('password')),
                'imgpelanggan' => url('upload/imgpelanggan/' . $gambar),
                'action' => 1,
                'api_token' => $token
            ];
        } else {
            $token = Str::random(40);
            $data = [
                'username' => $request->input('username'),
                'namapengguna' => $request->input('namapengguna'),
                'notelp' => $request->input('notelp'),
                'password' => Hash::make($request->input('password')),
                'action' => 1,
                'api_token' => $token
            ];
        }
        $pelanggan = Pelanggan::where('idpelanggan', $id)->update($data);
        $tampil = Pelanggan::where('idpelanggan', $id)->get();
        if ($pelanggan) {
            return response()->json([
                'success' => true,
                'message' => 'Profile berhasil diubah!',
                'data' => $tampil
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Profile gagal diubah!',
                'data' => ''
            ]);
        }
    }
    public function updatepelanggan(Request $request, $id)
    {
        $this->validate($request, [
            'username' => 'required | unique:pelanggans',
            'namapengguna' => 'required',
        ]);
        $data = [
            'username' => $request->input('username'),
            'namapengguna' => $request->input('namapengguna'),
        ];
        $pelanggan = Pelanggan::where('idpelanggan', $id)->update($data);
        if ($pelanggan) {
            return response()->json([
                'success' => true,
                'message' => 'data berhasil diubah'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'data gagal diubah'
            ]);
        }
    }
    public function gambar(Request $request, $id)
    {
        $gambar = $request->file('imgpelanggan')->getClientOriginalName();
        $request->file('imgpelanggan')->move('upload/imgpelanggan/', $gambar);
        $data = [
            'imgpelanggan' => url('upload/imgpelanggan/' . $gambar),
        ];
        $pelanggan = Pelanggan::where('idpelanggan', $id)->update($data);
        if ($pelanggan) {
            return response()->json([
                'success' => true,
                'message' => 'data berhasil diubah'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'message' => 'data gagal diubah'
            ]);
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pelanggan  $pelanggan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pelanggan $pelanggan)
    {
        //
    }
}
