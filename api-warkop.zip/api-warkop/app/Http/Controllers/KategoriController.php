<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::table('kategoris')
            ->join('warkops', 'warkops.idwarkop', '=', 'kategoris.idwarkop')
            ->select('kategoris.*', 'warkops.namawarung')
            ->get();

        if ($data) {
            return response()->json([
                'message' => 'Semua data',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'gagal data',
                'data' => ''
            ]);
        }
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'kategori' => 'required'
        ]);
        $kategori = Kategori::create($request->all());
        if ($kategori) {
            return response()->json([
                'message' => 'data sudah ditambahkan',
                'data' => $kategori
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal ditambahkan',
                'data' => ''
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Kategori::where('idwarkop', $id)->get();
        if ($data) {
            return response()->json([
                'message' => 'data berhasil',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal',
                'data' => ''
            ]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function edit(Kategori $kategori)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'kategori' => 'required'
        ]);
        $kategori = Kategori::where('idkategori', $id)->update($request->all());
        $biodata = Kategori::where('idkategori', $id)->get();
        if ($kategori) {
            return response()->json([
                'message' => 'Update data berhasil',
                'data' => $biodata
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal diubah',
                'data' => ''
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kategori  $kategori
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kategori = Kategori::where('idkategori', $id)->delete();
        if ($kategori) {
            return response()->json([
                'message' => 'data berhasil dihapus'
            ]);
        } else {
            return response()->json([
                'message' => 'data gagal dihapus'
            ]);
        }
    }
}
