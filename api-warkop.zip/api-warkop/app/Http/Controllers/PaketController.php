<?php

namespace App\Http\Controllers;

use App\Models\paket;
use Illuminate\Http\Request;

class PaketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = Paket::all();
        return response()->json($data);
    }

    /**
     * Show the form for creating am new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $paket = Paket::create($request->all());
        if ($paket) {
            return response()->json([
                'success' => true,
                'data' => $paket,
                'message' => 'paket sudah ditambahkan'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'data' => $paket,
                'message' => 'paket gagal ditambahkan'
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\paket  $paket
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $data = Paket::where('idpaket', $id)->get();
        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\paket  $paket
     * @return \Illuminate\Http\Response
     */
    public function edit(paket $paket)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\paket  $paket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $paket = Paket::where('idpaket', $id)->update($request->all());
        $tampil = Paket::where('idpaket', $id)->get();
        if ($paket) {
            return response()->json([
                'success' => true,
                'data' => $tampil,
                'message' => 'paket berhasil diupdate'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'data' => '',
                'message' => 'paket gagal diupdate'
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\paket  $paket
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $paket = Paket::where('idpaket', $id)->delete();
        if ($paket) {
            return response()->json([
                'success' => true,
                'message' => 'paket sudah dihapus'
            ]);
        } else {
            return response()->json([
                'success' => true,
                'message' => 'paket gagal dihapus'
            ]);
        }
        return response()->json("data sudah dihapus");
    }
}
