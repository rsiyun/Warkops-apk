<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->post('api/loginpelanggan', ['uses' => 'PelangganController@login']);
$router->post('api/registerpelanggan', ['uses' => 'PelangganController@create']);
$router->post('api/pelangganCari', ['uses' => 'PelangganController@showLp']);
$router->post('api/lppelanggan/{id}', ['uses' => 'PelangganController@LupaPassword']);

$router->post('api/loginwarkop', ['uses' => 'WarkopController@login']);
$router->post('api/registerwarkop', ['uses' => 'WarkopController@create']);

$router->post('api/loginadmin', ['uses' => 'AdminController@login']);
$router->post('api/registeradmin', ['uses' => 'AdminController@create']);

$router->group(['prefix' => 'api'], function () use ($router) {
    //done
    $router->get('kategori', ['uses' => 'KategoriController@index']);
    $router->get('kategori/{id}', ['uses' => 'KategoriController@show']);
    $router->delete('kategori/{id}', ['uses' => 'KategoriController@destroy']);
    $router->put('kategori/{id}', ['uses' => 'KategoriController@update']);
    $router->post('kategori', ['uses' => 'KategoriController@create']);
    //done
    $router->get('menu', ['uses' => 'MenuController@index']);
    $router->get('menu/{id}', ['uses' => 'MenuController@show']);
    $router->get('untukCart/{id}/{id2}', ['uses' => 'MenuController@untukCart']);
    $router->delete('menu/{id}', ['uses' => 'MenuController@destroy']);
    $router->post('menu', ['uses' => 'MenuController@create']);
    $router->post('menu/{id}', ['uses' => 'MenuController@update']);
    $router->post('menuG/{id}', ['uses' => 'MenuController@gambar']);
    //done
    $router->get('pelanggan', ['uses' => 'PelangganController@index']);
    $router->get('pelanggan/{id}', ['uses' => 'PelangganController@show']);
    // $router->post('pelanggan/{id}', ['uses' => 'PelangganController@update']);
    $router->post('pelanggan/{id}', ['uses' => 'PelangganController@updatepelanggan']);
    //done
    $router->get('warkop', ['uses' => 'WarkopController@index']);
    $router->get('warkop/{id}', ['uses' => 'WarkopController@show']);
    $router->post('warkop/{id}', ['uses' => 'WarkopController@update']);

    $router->get('paket', ['uses' => 'PaketController@index']);
    $router->get('paket/{id}', ['uses' => 'PaketController@show']);
    $router->delete('paket/{id}', ['uses' => 'PaketController@destroy']);
    $router->post('paket', ['uses' => 'PaketController@create']);
    $router->put('paket/{id}', ['uses' => 'PaketController@update']);

    $router->get('order', ['uses' => 'OrderController@index']);
    $router->get('order/{id}', ['uses' => 'OrderController@show']);
    $router->get('orderD/{id}', ['uses' => 'OrderController@untukDetail']);
    $router->get('orderSelesai/{id}', ['uses' => 'OrderController@show2']);
    $router->get('orderW/{id}', ['uses' => 'OrderController@show3']);
    $router->get('orderSelesaiW/{id}', ['uses' => 'OrderController@show4']);
    $router->post('order', ['uses' => 'OrderController@create']);
    $router->put('order/{id}', ['uses' => 'OrderController@update']);

    $router->get('detail', ['uses' => 'DetailController@index']);
    $router->get('detail/{id}', ['uses' => 'DetailController@show']);
    $router->post('detail', ['uses' => 'DetailController@create']);

    $router->get('transaksi', ['uses' => 'TransaksiController@index']);
    $router->get('transaksi/{id}', ['uses' => 'TransaksiController@show']);
    $router->post('transaksi', ['uses' => 'TransaksiController@create']);
});
