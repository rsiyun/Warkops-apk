package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.Menu;
import com.rsiyun.warkops.Model.MenuWarkop;

import java.util.List;

public class GetMenuWarkop {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<MenuWarkop> menuWarkopList;

    public GetMenuWarkop(String message, List<MenuWarkop> menuWarkopList) {
        this.message = message;
        this.menuWarkopList = menuWarkopList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<MenuWarkop> getMenuWarkopList() {
        return menuWarkopList;
    }

    public void setMenuWarkopList(List<MenuWarkop> menuWarkopList) {
        this.menuWarkopList = menuWarkopList;
    }
}
