package com.rsiyun.warkops.Model;

import com.google.gson.annotations.SerializedName;

public class PostPutDelKategori {
    @SerializedName("status")
    String status;
    @SerializedName("result")
    KategoriMenu mKategori;
    @SerializedName("message")
    String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public KategoriMenu getmKategori() {
        return mKategori;
    }

    public void setmKategori(KategoriMenu mKategori) {
        this.mKategori = mKategori;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
