package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.DetailPesananSelesaiActivity;
import com.rsiyun.warkops.Model.PesananSelesai;
import com.rsiyun.warkops.R;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PesananSelesaiAdapter extends RecyclerView.Adapter<PesananSelesaiAdapter.ViewHolder> {
    Context context;
    List<PesananSelesai> pesananSelesaiList;

    public PesananSelesaiAdapter(Context context, List<PesananSelesai> pesananSelesaiList) {
        this.context = context;
        this.pesananSelesaiList = pesananSelesaiList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan_selesai,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PesananSelesai pesananSelesai = pesananSelesaiList.get(position);
        holder.tvNamaWarkop.setText(pesananSelesai.getNamaWarung());
        Glide.with(context).load(""+pesananSelesai.getImgWarkop()).into(holder.ivGambar);
        if (pesananSelesai.getStatus().equals(1)) {
            holder.itemView.setVisibility(View.INVISIBLE);
        }else if (pesananSelesai.getStatus().equals(2)){
            holder.itemView.setVisibility(View.INVISIBLE);
        }else{
            holder.tvStatus.setText("Selesai");
        }
        holder.tvtglSelesai.setText(pesananSelesai.getTgl());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailPesananSelesaiActivity.class);
                intent.putExtra("idorder", pesananSelesaiList.get(position).getIdorder());
                intent.putExtra("namawarung", pesananSelesaiList.get(position).getNamaWarung());
                intent.putExtra("status", pesananSelesaiList.get(position).getStatus());
                intent.putExtra("tgl", pesananSelesaiList.get(position).getTgl());
                intent.putExtra("notelp", pesananSelesaiList.get(position).getNoTelp());
                intent.putExtra("total", pesananSelesaiList.get(position).getTotal());
                intent.putExtra("rating", pesananSelesaiList.get(position).getRating());
                intent.putExtra("imgwarkop", pesananSelesaiList.get(position).getImgWarkop());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pesananSelesaiList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaWarkop, tvJamSelesai, tvStatus, tvtglSelesai;
        CircleImageView ivGambar;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaWarkop = itemView.findViewById(R.id.tvNamaWarkop);
//            tvJamSelesai = itemView.findViewById(R.id.tvJamSelesai);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvtglSelesai = itemView.findViewById(R.id.tvtglSelesai);
            ivGambar = itemView.findViewById(R.id.ivGambar);
        }
    }
}
