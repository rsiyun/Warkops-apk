package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.R;

import java.util.List;

public class DetailPesananAdapter extends RecyclerView.Adapter<DetailPesananAdapter.ViewHolder> {
    Context context;
    List<DetailPesanan> detailPesananList;

    public DetailPesananAdapter(Context context, List<DetailPesanan> detailPesananList) {
        this.context = context;
        this.detailPesananList = detailPesananList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail_pesanan,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DetailPesanan detailPesanan = detailPesananList.get(position);
        Integer total = Integer.parseInt(detailPesanan.getHarga())*Integer.parseInt(detailPesanan.getJumlah());
        holder.tvNamaMenu.setText(detailPesanan.getMenu());
        Glide.with(context).load(""+detailPesanan.getImgmenu()).into(holder.imgMenu);
        holder.tvHarga.setText(total+"");
        holder.tvJumlah.setText(detailPesanan.getJumlah());
    }

    @Override
    public int getItemCount() {
        return detailPesananList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaMenu, tvHarga, tvJumlah;
        ImageView imgMenu;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaMenu = itemView.findViewById(R.id.tvNamaMenuDetail);
            tvHarga = itemView.findViewById(R.id.tvHargaDetail);
            tvJumlah = itemView.findViewById(R.id.tvJumlahDetail);
            imgMenu = itemView.findViewById(R.id.ivGambar);
        }
    }
}
