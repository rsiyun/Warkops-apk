package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.PesananWarkop;

import java.util.List;

public class GetPesananWarkop {
    @SerializedName("message")
    private String message;
    @SerializedName("data")
    private List<PesananWarkop> pesananWarkopList;

    public GetPesananWarkop(String message, List<PesananWarkop> pesananWarkopList) {
        this.message = message;
        this.pesananWarkopList = pesananWarkopList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<PesananWarkop> getPesananWarkopList() {
        return pesananWarkopList;
    }

    public void setPesananWarkopList(List<PesananWarkop> pesananWarkopList) {
        this.pesananWarkopList = pesananWarkopList;
    }
}
