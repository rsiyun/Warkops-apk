package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatRatingBar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.rsiyun.warkops.R;

public class RatingWarkopActivity extends AppCompatActivity {
    TextView tvRate;
    AppCompatRatingBar rbPenilaian;
    Button btnSubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_warkop);
        load();
        rbPenilaian.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                tvRate.setText("Rating: "+rating);
            }
        });
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(RatingWarkopActivity.this, ""+rbPenilaian.getRating(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void load(){
        rbPenilaian = findViewById(R.id.rbPenilaian);
        tvRate = findViewById(R.id.tvRate);
        btnSubmit = findViewById(R.id.submit);
    }
}