package com.rsiyun.warkops.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.PengaturanWarkop;
import com.rsiyun.warkops.Activity.RatingMelihat;
import com.rsiyun.warkops.Activity.RatingWarkopActivity;
import com.rsiyun.warkops.R;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileWarungFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileWarungFragment extends Fragment {
    View rootView;
    CardView btnPengaturan, btnRatingWarkop;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    TextView tvNamaWarkop, tvNamaPengguna,tvNoTelp;
    String username,namaWarung, namaPengguna,noTelp,imgWarkop,rating;
    Integer id;

    CircleImageView ivFotoWarung;
    public static final String sessionW = "SessionW";
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public void getSession(){
        id = pref.getInt("idwarkop",0);
        username = pref.getString("username","");
        namaWarung = pref.getString("namaWarung","");
        namaPengguna = pref.getString("namaPengguna","");
        noTelp = pref.getString("noTelp","");
        imgWarkop = pref.getString("imgWarkop","");
        rating = pref.getString("rating","");
    }
    public void load(){
        btnPengaturan = rootView.findViewById(R.id.btnPengaturan);
        btnRatingWarkop = rootView.findViewById(R.id.btnRatingWarkop);
        tvNamaPengguna = rootView.findViewById(R.id.tvNamaPengguna);
        tvNamaWarkop = rootView.findViewById(R.id.tvNamaWarkop);
        tvNoTelp = rootView.findViewById(R.id.tvNoTelp);
        ivFotoWarung = rootView.findViewById(R.id.ivFotoWarung);
        pref = getContext().getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        getSession();
        if (id==0){
            Toast.makeText(getActivity(), "Login Dulu Brother", Toast.LENGTH_SHORT).show();
        }else{
            tvNamaWarkop.setText(namaWarung);
            tvNamaPengguna.setText(namaPengguna);
            tvNoTelp.setText(noTelp);
            Glide.with(getContext()).load(""+imgWarkop).into(ivFotoWarung);
        }
    }
    public ProfileWarungFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileWarungFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileWarungFragment newInstance(String param1, String param2) {
        ProfileWarungFragment fragment = new ProfileWarungFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_profile_warung, container, false);
        load();
        btnPengaturan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PengaturanWarkop.class);
                startActivity(intent);
            }
        });
        btnRatingWarkop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), RatingMelihat.class);
                startActivity(intent);
            }
        });
        return rootView;
    }
}