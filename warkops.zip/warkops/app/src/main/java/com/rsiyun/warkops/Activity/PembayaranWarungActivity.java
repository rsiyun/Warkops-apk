package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.Model.Paket;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.List;

import retrofit2.Call;

public class PembayaranWarungActivity extends AppCompatActivity {
    LinearLayout btnTrial;
//    ApiInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran_warung);
        getSupportActionBar().hide();
        load();
        btnTrial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainMenuWarungActivity();
            }
        });
    }
//    public void panggil(){
//        Call<List<Paket>> call = ApiClient.getClient().create(ApiInterface.class).getPaket();
//        call.enqueue();
//    }
    public void load(){
        btnTrial = findViewById(R.id.btnTrial);
    }
    public void MainMenuWarungActivity(){
        Intent intent = new Intent(this, MainMenuWarungActivity.class);
        startActivity(intent);
    }
}