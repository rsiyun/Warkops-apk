package com.rsiyun.warkops.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.rsiyun.warkops.Adapter.PesananSelesaiAdapter;
import com.rsiyun.warkops.Get.GetPesananSelesai;
import com.rsiyun.warkops.Model.PesananSelesai;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SelesaiOrderFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SelesaiOrderFragment extends Fragment implements View.OnClickListener {
    View rootView;
    RecyclerView recyclerView;
    PesananSelesaiAdapter adapter;
    List<PesananSelesai> pesananSelesaiList;
    ApiInterface apiInterface;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String session = "Session";
    Integer idpelanggan;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SelesaiOrderFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SelesaiOrderFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SelesaiOrderFragment newInstance(String param1, String param2) {
        SelesaiOrderFragment fragment = new SelesaiOrderFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    public void load(){
        recyclerView = (RecyclerView) rootView.findViewById(R.id.rcvSelesaiPesanan);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getContext().getSharedPreferences(session, Context.MODE_PRIVATE);
        idpelanggan = pref.getInt("idPelanggan",0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_selesai_order, container, false);
        Button btnBerlangsung = (Button) rootView.findViewById(R.id.btnBerlangsung);
        btnBerlangsung.setOnClickListener(this);
        load();
        isiData();
        return rootView;
    }
    public void isiData(){
        if (idpelanggan==0){
            Toast.makeText(getActivity(), "LoginDuluBrother", Toast.LENGTH_SHORT).show();
        }else{
            Call<GetPesananSelesai> pesananSelesaiCall = apiInterface.getPesananSelesai(""+idpelanggan);
            pesananSelesaiCall.enqueue(new Callback<GetPesananSelesai>() {
                @Override
                public void onResponse(Call<GetPesananSelesai> call, Response<GetPesananSelesai> response) {
                    pesananSelesaiList = response.body().getPesananList();
                    if (pesananSelesaiList.size()==0){
                        Toast.makeText(getActivity(), "Data Kosong", Toast.LENGTH_SHORT).show();
                    }else{
                        Log.d("Retrofit Get", "Jumlah data Kontak: " +
                                String.valueOf(pesananSelesaiList.size()));
                        adapter = new PesananSelesaiAdapter(getActivity(),pesananSelesaiList);
                        recyclerView.setAdapter(adapter);
                    }

                }

                @Override
                public void onFailure(Call<GetPesananSelesai> call, Throwable t) {
                    Log.e("Retrofit Get", t.toString());
                }
            });
        }

    }
    @Override
    public void onClick(View v) {
        Fragment fragment = null;
        switch (v.getId()){
            case R.id.btnBerlangsung:
                fragment = new PesananFragment();
                replaceFragment(fragment);
                break;
        }
    }
    public void replaceFragment(Fragment someFragment){
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, someFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}