package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.rsiyun.warkops.R;

import java.util.ArrayList;

public class UbahMenuActivity extends AppCompatActivity {
    Toolbar toolbar;
    Spinner spKategoriMenu, spStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_menu);
        toolbar();
        spinner();
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarUbahMenu);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void spinner(){
        spKategoriMenu = findViewById(R.id.spKategoriMenuUbah);
        spStatus = findViewById(R.id.spStatusUbah);
        ArrayList<String> kategoriList = new ArrayList<>();
        ArrayList<String> statusList = new ArrayList<>();
        kategoriList.add(0,"Kategori");
        kategoriList.add("Makanan");
        kategoriList.add("Minuman");

        statusList.add(0, "Status Habis/Ada");
        statusList.add("Habis");
        statusList.add("Ada");
        ArrayAdapter<String> KategoriAdapter;
        ArrayAdapter<String> StatusAdapter;
        KategoriAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kategoriList);
        KategoriAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        StatusAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statusList);
        StatusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategoriMenu.setAdapter(KategoriAdapter);
        spStatus.setAdapter(StatusAdapter);
    }
}