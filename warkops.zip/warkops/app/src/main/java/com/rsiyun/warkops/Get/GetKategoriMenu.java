package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.KategoriMenu;

import java.util.List;

public class GetKategoriMenu {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<KategoriMenu> kategoriMenuList;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<KategoriMenu> getKategoriMenuList() {
        return kategoriMenuList;
    }

    public void setKategoriMenuList(List<KategoriMenu> kategoriMenuList) {
        this.kategoriMenuList = kategoriMenuList;
    }
}
