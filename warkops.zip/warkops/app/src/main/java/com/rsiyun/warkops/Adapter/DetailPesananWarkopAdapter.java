package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.Model.DetailPesananWarkop;
import com.rsiyun.warkops.R;

import java.util.List;

public class DetailPesananWarkopAdapter extends RecyclerView.Adapter<DetailPesananWarkopAdapter.ViewHolder> {
    Context context;
    List<DetailPesanan> detailPesananWarkopList;

    public DetailPesananWarkopAdapter(Context context, List<DetailPesanan> detailPesananWarkopList) {
        this.context = context;
        this.detailPesananWarkopList = detailPesananWarkopList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan_detail_warkop,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DetailPesanan detailPesananWarkop = detailPesananWarkopList.get(position);
        holder.tvNamaMenu.setText(detailPesananWarkop.getMenu());
        holder.tvHarga.setText(detailPesananWarkop.getHarga());
        holder.tvJumlah.setText(detailPesananWarkop.getJumlah());
        Glide.with(context).load(""+detailPesananWarkop.getImgmenu()).into(holder.ivGambar);
    }

    @Override
    public int getItemCount() {
        return detailPesananWarkopList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaMenu, tvHarga, tvJumlah;
        ImageView ivGambar;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivGambar = itemView.findViewById(R.id.ivGambar);
            tvJumlah = itemView.findViewById(R.id.tvJumlahMenu);
            tvHarga = itemView.findViewById(R.id.tvHargaDetailWarkop);
            tvNamaMenu = itemView.findViewById(R.id.tvNamaMenuDetailWarkop);
        }
    }
}
