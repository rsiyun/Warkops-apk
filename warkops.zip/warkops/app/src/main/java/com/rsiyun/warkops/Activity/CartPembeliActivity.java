package com.rsiyun.warkops.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rsiyun.warkops.Adapter.CartAdapter;
import com.rsiyun.warkops.Get.GetPesananWarkop;
import com.rsiyun.warkops.Get.TambahDetail;
import com.rsiyun.warkops.Get.TambahOrder;
import com.rsiyun.warkops.Model.Cart;
import com.rsiyun.warkops.Model.Pesanan;
import com.rsiyun.warkops.Model.PesananWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;
import com.rsiyun.warkops.Rest.DbWarkop;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartPembeliActivity extends AppCompatActivity {
    private Toolbar toolbarCart;
    RecyclerView rcvCart;
    List<Cart> cartList;
    List<PesananWarkop> orderList;
    ArrayList<String> totalArray;
    DbWarkop dbWarkop;
    CartAdapter adapter;
    TextView tvTotal, tvTotal1;
    String idCart,idpelanggan, idorder, idmenu, menu, gambarMenu, harga, jumlah, idWarkop, namaWarkop, alamat;
    ApiInterface apiInterface;
//    public static final String session = "Session";
//    SharedPreferences pref;
    double Total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_pembeli);
        toolbar();
        load();
        SelectData();
        setTotal();
    }
    public void onBackPressed() {

        // Put your own code here which you want to run on back button click.
        Intent intent = new Intent(this, WarkopActivity.class);
        intent.putExtra("idwarkop", idWarkop);
        intent.putExtra("namaWarkop", namaWarkop );
        intent.putExtra("alamat", alamat );
        startActivity(intent);
    }
    public void toolbar(){
        toolbarCart = findViewById(R.id.toolbarCart);
        setSupportActionBar(toolbarCart);
        toolbarCart.setNavigationIcon(R.drawable.ic_back);
        toolbarCart.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void load(){
        rcvCart = findViewById(R.id.rcvCart);
        rcvCart.setLayoutManager(new LinearLayoutManager(this));
        dbWarkop = new DbWarkop(this);
        tvTotal = findViewById(R.id.tvTotal);
        tvTotal1 = findViewById(R.id.tvTotal1);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
    public void setTotal(){
        for (int i=0; i<totalArray.size(); i++){
            String newStuff = totalArray.get(i);
            Total = Total + Float.parseFloat(newStuff);
        }
        tvTotal1.setText("Rp. "+Total);
        tvTotal.setText("Rp. "+Total);
    }
    public void SelectData(){
        String sql = "SELECT * FROM cart";
        Cursor cursor = dbWarkop.select(sql);
        cartList = new ArrayList<Cart>();
        totalArray = new ArrayList<>();
        if (cursor.getCount() > 0){
            while (cursor.moveToNext()){
                idCart = cursor.getString(cursor.getColumnIndexOrThrow("idcart"));
                 idmenu = cursor.getString(cursor.getColumnIndexOrThrow("idmenu"));
                 menu = cursor.getString(cursor.getColumnIndexOrThrow("menu"));
                 gambarMenu = cursor.getString(cursor.getColumnIndexOrThrow("gambarMenu"));
                 harga = cursor.getString(cursor.getColumnIndexOrThrow("harga"));
                 jumlah = cursor.getString(cursor.getColumnIndexOrThrow("jumlah"));
                 idWarkop = cursor.getString(cursor.getColumnIndexOrThrow("idpenjual"));
                 namaWarkop = cursor.getString(cursor.getColumnIndexOrThrow("warkop"));
                 alamat = cursor.getString(cursor.getColumnIndexOrThrow("alamat"));
                 idpelanggan = cursor.getString(cursor.getColumnIndexOrThrow("idpelanggan"));
                 Float total = Integer.parseInt(jumlah) * Float.parseFloat(harga);
                 totalArray.add(""+total);
                cartList.add(new Cart(idCart, idmenu, menu, harga, jumlah, gambarMenu));
            }
            adapter = new CartAdapter(this, cartList);
            rcvCart.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }else{
            Toast.makeText(this, "data kosong", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnTambah(View view) {
        onBackPressed();
    }

    public void btnCatatan(View view) {
        Intent intent = new Intent(this, CatatanPembeli.class);
        startActivity(intent);
    }
    public void delete(){
        String sql = "DELETE From cart";
        dbWarkop.runSQL(sql);
    }
    public void btnPesan(View view) {
        Calendar calendar= Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String Date=simpleDateFormat.format(calendar.getTime());
        String Totals = Double.toString(Total);
        TambahOrder(idWarkop, idpelanggan, Date, "1", Totals);
        Selectidorder(idpelanggan);
//        Intent intent = new Intent(this, MainActivity.class);
//        startActivity(intent);
    }
    public void Selectidorder(String idpelanggan){
        Call<GetPesananWarkop> modal = apiInterface.getidOrder(idpelanggan);
        modal.enqueue(new Callback<GetPesananWarkop>() {
            @Override
            public void onResponse(Call<GetPesananWarkop> call, Response<GetPesananWarkop> response) {
                 orderList = response.body().getPesananWarkopList();
                idorder = orderList.get(0).getIdorder().toString();
                for (int i=0; i< cartList.size(); i++){
                    Log.d("idorder", idorder);
                    Log.d("idmenu", cartList.get(i).getIdmenu());
                    Log.d("jumlah", cartList.get(i).getJumlah());
                    Log.d("hargajual", totalArray.get(i));
                    Tambahdetailorder(idorder, cartList.get(i).getIdmenu(),cartList.get(i).getJumlah(), totalArray.get(i));
                    delete();
                    Intent intent = new Intent(CartPembeliActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onFailure(Call<GetPesananWarkop> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
    public void Tambahdetailorder(String idorder, String idmenu, String jumlah, String hargajual){
        TambahDetail tambahDetail = new TambahDetail(idorder, idmenu, jumlah, hargajual);
        Call<TambahDetail> call = apiInterface.TambahDetail(tambahDetail);
        call.enqueue(new Callback<TambahDetail>() {
            @Override
            public void onResponse(Call<TambahDetail> call, Response<TambahDetail> response) {
                Log.d("TambahdetailOrder", idorder);
            }

            @Override
            public void onFailure(Call<TambahDetail> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
    public void TambahOrder(String idWarkop, String idpelanggan, String tglorder, String status, String total){
        TambahOrder tambahOrder = new TambahOrder(idWarkop, idpelanggan, tglorder, status, total);
        Call<TambahOrder> call = apiInterface.TambahOrder(tambahOrder);
        call.enqueue(new Callback<TambahOrder>() {
            @Override
            public void onResponse(Call<TambahOrder> call, Response<TambahOrder> response) {
                Toast.makeText(CartPembeliActivity.this, "Tambah Data Berhasil", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<TambahOrder> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
}
