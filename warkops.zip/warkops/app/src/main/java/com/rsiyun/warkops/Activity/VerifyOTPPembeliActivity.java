package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.rsiyun.warkops.R;

public class VerifyOTPPembeliActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_o_t_p_pembeli);
    }
}