package com.rsiyun.warkops.Get;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.Pelanggan;

import java.util.List;

public class LoginPelanggan {
    @SerializedName("idpelanggan")
    @Expose
    private Integer idpelanggan;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("namapengguna")
    @Expose
    private String namapengguna;
    @SerializedName("imgpelanggan")
    @Expose
    private String imgpelanggan;
    @SerializedName("notelp")
    private String noTelp;

    public Integer getIdpelanggan() {
        return idpelanggan;
    }

    public void setIdpelanggan(Integer idpelanggan) {
        this.idpelanggan = idpelanggan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamapengguna() {
        return namapengguna;
    }

    public void setNamapengguna(String namapengguna) {
        this.namapengguna = namapengguna;
    }

    public String getImgpelanggan() {
        return imgpelanggan;
    }

    public void setImgpelanggan(String imgpelanggan) {
        this.imgpelanggan = imgpelanggan;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }
}
