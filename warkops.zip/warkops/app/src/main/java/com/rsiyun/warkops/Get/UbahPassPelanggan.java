package com.rsiyun.warkops.Get;

public class UbahPassPelanggan {
}
