package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class TambahMenu {
    @SerializedName("id")
    private String idmenu;
    @SerializedName("idkategori")
    private String idkategori;
    @SerializedName("menu")
    private String menu;
    @SerializedName("deskripsi")
    private String deskripsi;
//    @SerializedName("imgmenu")
//    private String imgmenu;
    @SerializedName("harga")
    private String harga;
    @SerializedName("status")
    private String status;

    public TambahMenu(String idkategori, String menu, String deskripsi, String harga, String status) {
        this.idkategori = idkategori;
        this.menu = menu;
        this.deskripsi = deskripsi;
//        this.imgmenu = imgmenu;
        this.harga = harga;
        this.status = status;
    }

    public String getIdmenu() {
        return idmenu;
    }

    public void setIdmenu(String idmenu) {
        this.idmenu = idmenu;
    }

    public String getIdkategori() {
        return idkategori;
    }

    public void setIdkategori(String idkategori) {
        this.idkategori = idkategori;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

//    public String getImgmenu() {
//        return imgmenu;
//    }
//
//    public void setImgmenu(String imgmenu) {
//        this.imgmenu = imgmenu;
//    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
