package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.DetailPesananWarkopSelesaiActivity;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.Model.PesananWarkop;
import com.rsiyun.warkops.Model.PesananWarkopSelesai;
import com.rsiyun.warkops.R;

import java.util.List;

public class PesananWarkopSelesaiAdapter extends RecyclerView.Adapter<PesananWarkopSelesaiAdapter.ViewHolder> {
    Context context;
    List<PesananWarkop> pesananWarkopSelesaiList;

    public PesananWarkopSelesaiAdapter(Context context, List<PesananWarkop> pesananWarkopSelesaiList) {
        this.context = context;
        this.pesananWarkopSelesaiList = pesananWarkopSelesaiList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan_warkop_selesai,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PesananWarkop pesananWarkopSelesai = pesananWarkopSelesaiList.get(position);
        holder.tvNamaPembeli.setText(pesananWarkopSelesai.getUsername());
//        holder.tvJam.setText(pesananWarkopSelesai.getJamSelesai());
        if (pesananWarkopSelesai.getStatus().equals(1)) {
            holder.itemView.setVisibility(View.INVISIBLE);
        }else if (pesananWarkopSelesai.getStatus().equals(2)){
            holder.itemView.setVisibility(View.INVISIBLE);
        }else{
            holder.tvStatus.setText("Selesai");
        }
        holder.tvtgl.setText(pesananWarkopSelesai.getTglorder());
        Glide.with(context).load(""+pesananWarkopSelesai.getImgPelanggan()).into(holder.ivFotoPembeli);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailPesananWarkopSelesaiActivity.class);
                intent.putExtra("Username",pesananWarkopSelesaiList.get(position).getUsername());
                intent.putExtra("alamat", pesananWarkopSelesaiList.get(position).getAlamat());
                intent.putExtra("tanggal", pesananWarkopSelesaiList.get(position).getTglorder());
                intent.putExtra("total", pesananWarkopSelesaiList.get(position).getTotal());
                intent.putExtra("status", pesananWarkopSelesaiList.get(position).getStatus());
                intent.putExtra("idorder", pesananWarkopSelesaiList.get(position).getIdorder());
                intent.putExtra("noTelp", pesananWarkopSelesaiList.get(position).getNotelp());
                intent.putExtra("imgPelanggan", pesananWarkopSelesaiList.get(position).getImgPelanggan());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pesananWarkopSelesaiList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaPembeli, tvStatus, tvtgl, tvJam;
        ImageView ivFotoPembeli;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaPembeli = itemView.findViewById(R.id.tvNamaPembeli);
            tvJam = itemView.findViewById(R.id.tvJam);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvtgl = itemView.findViewById(R.id.tvtgl);
            ivFotoPembeli = itemView.findViewById(R.id.ivFotoPembeli);
        }
    }
}
