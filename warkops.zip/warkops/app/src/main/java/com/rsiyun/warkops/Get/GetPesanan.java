package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.Pesanan;

import java.util.List;

public class GetPesanan {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<Pesanan> pesananList;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Pesanan> getPesananList() {
        return pesananList;
    }

    public void setPesananList(List<Pesanan> pesananList) {
        this.pesananList = pesananList;
    }
}
