package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.rsiyun.warkops.Get.GetPelangganUsername;
import com.rsiyun.warkops.Get.CariUsernamePembeliReq;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CariPelangganUsername extends AppCompatActivity {
    EditText etUsername;
    LinearLayout btnLupaPassword;
    ApiInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cari_pelanggan_username);
        getSupportActionBar().hide();
        load();
        btnLupaPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etUsername.getText().toString())){
                    etUsername.setError("Username Anda Harus ada");
                    etUsername.requestFocus();
                }else {
                    cariUser();
                }
            }
        });
    }
    public void cariUser(){
        CariUsernamePembeliReq cariUsernamePembeliReq = new CariUsernamePembeliReq();
        cariUsernamePembeliReq.setUsername(etUsername.getText().toString());
        Call<GetPelangganUsername> call = apiInterface.getDataPelanggan(cariUsernamePembeliReq);
        call.enqueue(new Callback<GetPelangganUsername>() {
            @Override
            public void onResponse(Call<GetPelangganUsername> call, Response<GetPelangganUsername> response) {
                if (response.body().getUsername() == null){
                    etUsername.setError("Username Belum Terdaftar");
                    etUsername.requestFocus();
                }else{
                    Intent intent = new Intent(CariPelangganUsername.this, LupaPasswordPelanggan.class);
                    intent.putExtra("idpelanggan",response.body().getIdpelanggan());
                    startActivity(intent);
                }
            }

            @Override
            public void onFailure(Call<GetPelangganUsername> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }
    public void load(){
        etUsername = findViewById(R.id.etUsername);
        btnLupaPassword = findViewById(R.id.BtnLupaPassword);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
}