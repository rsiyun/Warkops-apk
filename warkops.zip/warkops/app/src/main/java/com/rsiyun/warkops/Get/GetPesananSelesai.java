package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.PesananSelesai;

import java.util.List;

public class GetPesananSelesai {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<PesananSelesai> pesananList;

    public GetPesananSelesai(String message, List<PesananSelesai> pesananList) {
        this.message = message;
        this.pesananList = pesananList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<PesananSelesai> getPesananList() {
        return pesananList;
    }

    public void setPesananList(List<PesananSelesai> pesananList) {
        this.pesananList = pesananList;
    }
}
