package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.Model.KategoriMenu;

import java.util.List;

public class GetDetail {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<DetailPesanan> detailPesananList;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DetailPesanan> getDetailPesananList() {
        return detailPesananList;
    }

    public void setDetailPesananList(List<DetailPesanan> detailPesananList) {
        this.detailPesananList = detailPesananList;
    }
}
