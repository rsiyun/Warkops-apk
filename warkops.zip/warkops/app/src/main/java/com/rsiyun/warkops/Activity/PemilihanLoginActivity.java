package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;


import com.rsiyun.warkops.R;

public class PemilihanLoginActivity extends AppCompatActivity {
    LinearLayout login_pembeli,login_warung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemilihan_login);
        getSupportActionBar().hide();
        load();
        login_pembeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginPembeliActivity();
            }
        });
        login_warung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginWarungActivity();
            }
        });

    }
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void load(){
        login_pembeli = findViewById(R.id.login_pembeli);
        login_warung = findViewById(R.id.login_warung);

    }
    public void LoginPembeliActivity(){
        Intent intent = new Intent(this, LoginPembeliActivity.class);
        startActivity(intent);
    }
    public void LoginWarungActivity(){
        Intent intent = new Intent(this, LoginWarungActivity.class);
        startActivity(intent);
    }
}