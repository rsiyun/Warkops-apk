package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DetailPesanan {
    @SerializedName("iddetail")
    @Expose
    private String iddetail;
    @SerializedName("idorder")
    @Expose
    private String idorder;
    @SerializedName("idmenu")
    @Expose
    private String idmenu;
    @SerializedName("jumlah")
    @Expose
    private String jumlah;
    @SerializedName("tglorder")
    @Expose
    private String tglorder;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("menu")
    @Expose
    private String menu;
    @SerializedName("harga")
    private String harga;
    @SerializedName("imgmenu")
    private String imgmenu;

    public DetailPesanan(String iddetail, String idorder, String idmenu, String jumlah, String tglorder, Integer status, String menu, String harga, String imgmenu) {
        this.iddetail = iddetail;
        this.idorder = idorder;
        this.idmenu = idmenu;
        this.jumlah = jumlah;
        this.tglorder = tglorder;
        this.status = status;
        this.menu = menu;
        this.harga = harga;
        this.imgmenu = imgmenu;
    }

    public String getIddetail() {
        return iddetail;
    }

    public void setIddetail(String iddetail) {
        this.iddetail = iddetail;
    }

    public String getIdorder() {
        return idorder;
    }

    public void setIdorder(String idorder) {
        this.idorder = idorder;
    }

    public String getIdmenu() {
        return idmenu;
    }

    public void setIdmenu(String idmenu) {
        this.idmenu = idmenu;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getTglorder() {
        return tglorder;
    }

    public void setTglorder(String tglorder) {
        this.tglorder = tglorder;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getImgmenu() {
        return imgmenu;
    }

    public void setImgmenu(String imgmenu) {
        this.imgmenu = imgmenu;
    }
}
