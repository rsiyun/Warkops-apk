package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Adapter.DetailPesananWarkopAdapter;
import com.rsiyun.warkops.Get.GetDetail;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.Model.DetailPesananWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPesananWarkopActivity extends AppCompatActivity {
    Toolbar toolbar;
    RecyclerView recyclerView;
    DetailPesananWarkopAdapter adapter;
    List<DetailPesanan> detailPesananWarkopList;
    CircleImageView ivFotoPembeli;
    TextView tvNamaPembeli,tvAlamatPembeli, tvTglOrder, tvTotal, tvStatus, tvStatus2;
    String sUsername, sAlamat, sNotelp, sImgPelanggan, sTglOrder;
    Integer  sIdorder,sStatus, sTotal;
    ApiInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pesanan_warkop);
        toolbar();
        load();
        getIntentKu();
        setIntentKu();
        isiData();
    }
    public void load(){
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        recyclerView = findViewById(R.id.rcvDetailPesananWarkop);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tvNamaPembeli = findViewById(R.id.tvNamaPembeli);
        tvAlamatPembeli = findViewById(R.id.tvAlamatPembeli);
        tvTglOrder = findViewById(R.id.tvTglOrder);
        tvStatus = findViewById(R.id.tvStatus);
        tvStatus2 = findViewById(R.id.tvStatus2);
        tvTotal = findViewById(R.id.tvTotal);
        ivFotoPembeli = findViewById(R.id.ivFotoPembeli);
    }
    public void getIntentKu(){
        Intent intent = getIntent();
        sUsername = intent.getStringExtra("Username");
        sAlamat = intent.getStringExtra("alamat");
        sTglOrder = intent.getStringExtra("tanggal");
        sTotal = intent.getIntExtra("total",0);
        sStatus = intent.getIntExtra("status",0);
        sNotelp = intent.getStringExtra("noTelp");
        sIdorder = intent.getIntExtra("idorder", 0);
        sImgPelanggan = intent.getStringExtra("imgPelanggan");
    }
    public void setIntentKu(){
        tvNamaPembeli.setText(sUsername);
        tvAlamatPembeli.setText(sAlamat);
        tvTglOrder.setText(sTglOrder);
        Glide.with(this).load(""+sImgPelanggan).into(ivFotoPembeli);
        tvTotal.setText(""+sTotal);
        if (sStatus.equals(1)) {
            tvStatus.setText("Pesanan Sedang disiapkan");
            tvStatus2.setText("Pesanan Sedang disiapkan");
        }
        else if(sStatus.equals(2)){
            tvStatus.setText("pesan Sedang diantar");
            tvStatus2.setText("pesan Sedang diantar");
        }else{
            tvStatus.setText("halo");
            tvStatus.setText("halo");
        }
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarDetailPesananWarkop);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void isiData(){
        Call<GetDetail> detailCall = apiInterface.getDetail(""+sIdorder);
        detailCall.enqueue(new Callback<GetDetail>() {
            @Override
            public void onResponse(Call<GetDetail> call, Response<GetDetail> response) {
                detailPesananWarkopList = response.body().getDetailPesananList();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(detailPesananWarkopList.size()));
                adapter = new DetailPesananWarkopAdapter(DetailPesananWarkopActivity.this, detailPesananWarkopList);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<GetDetail> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }
}