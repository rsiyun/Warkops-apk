package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.Get.GantiPasswordPembeli;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LupaPasswordPelanggan extends AppCompatActivity {
    EditText etPasswordBaru;
    LinearLayout btnGantiPassword;
    ApiInterface apiInterface;
    Integer idpelanggan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lupa_password_pelanggan);
        getSupportActionBar().hide();
        load();
        btnGantiPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etPasswordBaru.getText().toString())||etPasswordBaru.length()<8){
                    etPasswordBaru.setError("Password harus diisi / minimal 8 karakter");
                    etPasswordBaru.requestFocus();
                }else if (!isValidPassword(etPasswordBaru.getText().toString())){
                    etPasswordBaru.setError("Password Minimal 1 huruf kapital, 1 angka, 1 character");
                    etPasswordBaru.requestFocus();
                }
                else{
                    GantiPassword(etPasswordBaru.getText().toString());
                }
            }
        });
    }
    public void load(){
        etPasswordBaru = findViewById(R.id.etPasswordBaru);
        btnGantiPassword = findViewById(R.id.btnGantiPassword);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Intent intent = getIntent();
        idpelanggan = intent.getIntExtra("idpelanggan",0);
    }
    public static boolean isValidPassword(final String password){
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }
    public void GantiPassword(String password){
        GantiPasswordPembeli gantiPasswordPembeli = new GantiPasswordPembeli(password);
        Call<GantiPasswordPembeli> call = apiInterface.gantiPasswordPembeli(""+idpelanggan,gantiPasswordPembeli);
        call.enqueue(new Callback<GantiPasswordPembeli>() {
            @Override
            public void onResponse(Call<GantiPasswordPembeli> call, Response<GantiPasswordPembeli> response) {
                if (response.isSuccessful()){
                    Toast.makeText(LupaPasswordPelanggan.this, "Ganti Password Berhasil", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LupaPasswordPelanggan.this, LoginPembeliActivity.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(LupaPasswordPelanggan.this, "Gagal", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GantiPasswordPembeli> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
}