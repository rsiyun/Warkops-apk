package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class TambahDetail {
    @SerializedName("idorder")
    private String idorder;
    @SerializedName("idmenu")
    private String idmenu;
    @SerializedName("jumlah")
    private String jumlah;
    @SerializedName("hargajual")
    private String hargaJual;

    public TambahDetail(String idorder, String idmenu, String jumlah, String hargaJual) {
        this.idorder = idorder;
        this.idmenu = idmenu;
        this.jumlah = jumlah;
        this.hargaJual = hargaJual;
    }

    public String getIdorder() {
        return idorder;
    }

    public void setIdorder(String idorder) {
        this.idorder = idorder;
    }

    public String getIdmenu() {
        return idmenu;
    }

    public void setIdmenu(String idmenu) {
        this.idmenu = idmenu;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getHargaJual() {
        return hargaJual;
    }

    public void setHargaJual(String hargaJual) {
        this.hargaJual = hargaJual;
    }
}
