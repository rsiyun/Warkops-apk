package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.rsiyun.warkops.R;

public class RegisterWarungActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_warung);
        getSupportActionBar().hide();
    }

    public void btnRegisterPembeli(View view) {
        Intent intent = new Intent(this, LoginWarungActivity.class);
        startActivity(intent);
    }
}