package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class UbahPelanggan {
    @SerializedName("username")
    private String idorder;
    @SerializedName("namapengguna")
    private String namaPengguna;

    public UbahPelanggan(String idorder, String namaPengguna) {
        this.idorder = idorder;
        this.namaPengguna = namaPengguna;
    }

    public String getIdorder() {
        return idorder;
    }

    public void setIdorder(String idorder) {
        this.idorder = idorder;
    }

    public String getNamaPengguna() {
        return namaPengguna;
    }

    public void setNamaPengguna(String namaPengguna) {
        this.namaPengguna = namaPengguna;
    }
}
