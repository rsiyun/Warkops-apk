package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.Get.LoginPelanggan;
import com.rsiyun.warkops.Get.LoginRequest;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginPembeliActivity extends AppCompatActivity {
    LinearLayout login_pembeli,register_pembeli;
    EditText etUsername,etPassword;
    ApiInterface apiInterface;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String session = "Session";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_pembeli);
        load();
        getSupportActionBar().hide();
        login_pembeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etUsername.getText().toString())){
                    etUsername.setError("Username anda harus diisi");
                    etUsername.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(etPassword.getText().toString())){
                    etPassword.setError("Password harus diisi");
                    etPassword.requestFocus();
                }else{
                    login();
                }

            }
        });
        register_pembeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterPembeliActivity();
            }
        });
    }
    public void login(){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(etUsername.getText().toString());
        loginRequest.setPassword(etPassword.getText().toString());
        Call<LoginPelanggan> call = apiInterface.getDataLogin(loginRequest);
        call.enqueue(new Callback<LoginPelanggan>() {
            @Override
            public void onResponse(Call<LoginPelanggan> call, Response<LoginPelanggan> response) {
                if (response.body() == null){
                    Toast.makeText(LoginPembeliActivity.this, "Username/Password Salah", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(LoginPembeliActivity.this, "Login sucess", Toast.LENGTH_SHORT).show();
                    pref = getSharedPreferences(session,MODE_PRIVATE);
                    editor = pref.edit();
                    editor.putInt("idPelanggan", response.body().getIdpelanggan());
                    editor.putString("username", response.body().getUsername());
                    editor.putString("namaPengguna", response.body().getNamapengguna());
                    editor.putString("noTelp", response.body().getNoTelp());
                    editor.putString("imgPelanggan", response.body().getImgpelanggan());
                    editor.apply();
                    MainActivity();
                }
            }

            @Override
            public void onFailure(Call<LoginPelanggan> call, Throwable t) {
                Toast.makeText(LoginPembeliActivity.this, "Username/Password Salah", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void load(){
        login_pembeli = findViewById(R.id.login_pembeli);
        register_pembeli = findViewById(R.id.register_pembeli);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
    public void MainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void RegisterPembeliActivity(){
        Intent intent = new Intent(this, RegisterPembeliActivity.class);
        startActivity(intent);
    }

    public void LupaPassword(View view) {
        Intent intent = new Intent(this, CariPelangganUsername.class);
        startActivity(intent);
    }
}