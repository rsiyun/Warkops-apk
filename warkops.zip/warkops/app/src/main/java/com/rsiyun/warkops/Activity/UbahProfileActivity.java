package com.rsiyun.warkops.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.rsiyun.warkops.Get.RegisterPembeliReq;
import com.rsiyun.warkops.Get.UbahGambarPelanggan;
import com.rsiyun.warkops.Get.UbahPelanggan;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UbahProfileActivity extends AppCompatActivity {
    EditText etUsername, etNamaPengguna;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String username, namaPengguna, imgPelanggan, noTelp;
    CircleImageView ivProfile;
    LinearLayout btnSimpan, btnUbahPassword, btnUbahNoTelp;
    Integer id;
    File file;
    ApiInterface apiInterface;
    public static final String session = "Session";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_profile);
        load();
        getSession();
        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImagePicker.with(UbahProfileActivity.this).crop().maxResultSize(1080, 1080).start();
            }
        });
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etUsername.getText().toString())){
                    etUsername.setError("Username Harus diisi");
                    etUsername.requestFocus();
                }else if (TextUtils.isEmpty(etNamaPengguna.getText().toString())){
                    etNamaPengguna.setError("Nama Pengguna harus diisi");
                    etNamaPengguna.requestFocus();
                }else {
                    ubahPelanggan(etUsername.getText().toString(), etNamaPengguna.getText().toString());
                }
            }
        });
    }
    public void load(){
        etNamaPengguna = findViewById(R.id.namaPengguna);
        etUsername = findViewById(R.id.username);
        ivProfile = findViewById(R.id.ivProfile);
        btnUbahPassword = findViewById(R.id.btnUbahPassword);
        btnUbahNoTelp = findViewById(R.id.btnUbahTelp);
        btnSimpan = findViewById(R.id.btnSimpan);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
    public void ubahPelanggan(String username, String namaPengguna){
//        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
//        MultipartBody.Part filePart = MultipartBody.Part.createFormData("imgpelanggan", file.getName(), requestFile);
        UbahPelanggan modal = new UbahPelanggan(username, namaPengguna);
        Call<UbahPelanggan> ubahUserPengguna = apiInterface.ubahPelanggan(""+id, modal);
        ubahUserPengguna.enqueue(new Callback<UbahPelanggan>() {
            @Override
            public void onResponse(Call<UbahPelanggan> call, Response<UbahPelanggan> response) {
//                Call<UbahGambarPelanggan> pelangganG = apiInterface.UbahGambarPelanggan(id.toString(), filePart);
//                pelangganG.enqueue(new Callback<UbahGambarPelanggan>() {
//                    @Override
//                    public void onResponse(Call<UbahGambarPelanggan> call, Response<UbahGambarPelanggan> response) {
                        Toast.makeText(UbahProfileActivity.this, "berhasil ganti", Toast.LENGTH_SHORT).show();
                        pref = getSharedPreferences(session,MODE_PRIVATE);
                        editor = pref.edit();
                        editor.putString("username", username);
                        editor.putString("namaPengguna", namaPengguna);
                        editor.apply();
                        finish();
//                    }
//
//                    @Override
//                    public void onFailure(Call<UbahGambarPelanggan> call, Throwable throwable) {
//                        Toast.makeText(UbahProfileActivity.this, "berhasil ganti", Toast.LENGTH_SHORT).show();
//                        pref = getSharedPreferences(session,MODE_PRIVATE);
//                        editor = pref.edit();
//                        editor.putString("username", username);
//                        editor.putString("namaPengguna", namaPengguna);
//                        editor.apply();
//                        finish();
//                    }
//                });
            }

            @Override
            public void onFailure(Call<UbahPelanggan> call, Throwable throwable) {
                Toast.makeText(UbahProfileActivity.this, "gagal ganti", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void getSession(){
        pref = getSharedPreferences(session, Context.MODE_PRIVATE);
        id = pref.getInt("idPelanggan",0);
        username = pref.getString("username","");
        etUsername.setText(username);
        namaPengguna = pref.getString("namaPengguna","");
        etNamaPengguna.setText(namaPengguna);
        imgPelanggan = pref.getString("imgPelanggan","");
        Glide.with(this).load(""+imgPelanggan).circleCrop().into(ivProfile);
        noTelp = pref.getString("noTelp", "");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            Uri uri = data.getData();
            file = new File(uri.getPath());
        }
    }
}