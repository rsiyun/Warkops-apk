package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.rsiyun.warkops.Activity.CartPembeliActivity;
import com.rsiyun.warkops.Activity.MainActivity;
import com.rsiyun.warkops.Activity.WarkopActivity;
import com.rsiyun.warkops.Model.Cart;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.DbWarkop;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder>{
    private Context context;
    private List<Cart> cartList;

    public CartAdapter(Context context, List<Cart> cartList) {
        this.context = context;
        this.cartList = cartList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cart cart = cartList.get(position);
        holder.tvNamaMenuCart.setText(cart.getNamaMenu());
        holder.tvHargaCart.setText(cart.getHarga());
        holder.tvJumlah.setText(cart.getJumlah());
        holder.Tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer jumlah = Integer.parseInt(cart.getJumlah());
                Integer idmenu = Integer.parseInt(cart.getIdmenu());
                jumlah++;
                String sql = "UPDATE cart SET jumlah = "+jumlah+" WHERE idmenu = "+idmenu+"";
                holder.dbWarkop.runSQL(sql);
                Intent intent = new Intent(context, CartPembeliActivity.class);
                context.startActivity(intent);
            }
        });
        holder.Kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer jumlah = Integer.parseInt(cart.getJumlah());
                Integer idmenu = Integer.parseInt(cart.getIdmenu());
                Integer idcart = Integer.parseInt(cart.getIdCart());
                if (jumlah > 1){
                    jumlah--;
                    String sql = "UPDATE cart SET jumlah = "+jumlah+" WHERE idmenu = "+idmenu+"";
                    holder.dbWarkop.runSQL(sql);
                    Intent intent = new Intent(context, CartPembeliActivity.class);
                    context.startActivity(intent);
                }else{
                    String sql1 = "SELECT * FROM cart";
                    Cursor cursor = holder.dbWarkop.select(sql1);
                    if (cursor.getCount() > 1){
                        String sql = "DELETE FROM cart WHERE idcart = "+idcart+"";
                        holder.dbWarkop.runSQL(sql);
                        Intent intent = new Intent(context, CartPembeliActivity.class);
                        context.startActivity(intent);
                    }else{
                        String sql = "DELETE FROM cart WHERE idcart = "+idcart+"";
                        holder.dbWarkop.runSQL(sql);
                        Intent intent = new Intent(context, MainActivity.class);
                        context.startActivity(intent);
                    }

                }

            }
        });
        Glide.with(context).load(""+cart.getGambar()).override(203,223).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                return false;
            }
        }).into(holder.ivGambar);
    }

    @Override
    public int getItemCount() {
        return cartList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaMenuCart, tvHargaCart, tvJumlah, Tambah, Kurang;
        ImageView ivGambar;
        DbWarkop dbWarkop;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dbWarkop = new DbWarkop(context);
            tvNamaMenuCart = itemView.findViewById(R.id.tvNamaMenuCart);
            tvHargaCart = itemView.findViewById(R.id.tvHargaCart);
            tvJumlah = itemView.findViewById(R.id.tvQuantity);
            ivGambar = itemView.findViewById(R.id.ivGambar);
            Tambah = itemView.findViewById(R.id.tvTambahJum);
            Kurang = itemView.findViewById(R.id.tvKurangJum);
        }
    }
}
