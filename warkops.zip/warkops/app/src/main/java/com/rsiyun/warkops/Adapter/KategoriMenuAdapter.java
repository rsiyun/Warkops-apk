package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rsiyun.warkops.Activity.KategoriMenuWarungActivity;
import com.rsiyun.warkops.Activity.TambahKategoriActivity;
import com.rsiyun.warkops.Activity.UbahKategoriMenuActivity;
import com.rsiyun.warkops.Get.DelKategoriResp;
import com.rsiyun.warkops.Model.KategoriMenu;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KategoriMenuAdapter extends RecyclerView.Adapter<KategoriMenuAdapter.ViewHolder> {
    Context context;
    List<KategoriMenu> kategoriMenuList;
    ApiInterface apiInterface;

    public KategoriMenuAdapter(Context context, List<KategoriMenu> kategoriList) {
        this.context = context;
        this.kategoriMenuList = kategoriList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kategori,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        KategoriMenu kategoriMenu = kategoriMenuList.get(position);
        holder.tvKategori.setText(kategoriMenu.getKategori());
        holder.ivEditKategori1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hapusKategori(kategoriMenu.getIdkategori());
            }
        });
        holder.ivEditKategori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UbahKategoriMenuActivity.class);
                intent.putExtra("idkategori",kategoriMenu.getIdkategori());
                context.startActivity(intent);
            }
        });
    }
    public void hapusKategori(String idkategori){
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<DelKategoriResp> deleteKategori = apiInterface.deleteKategori(idkategori);
        deleteKategori.enqueue(new Callback<DelKategoriResp>() {
            @Override
            public void onResponse(Call<DelKategoriResp> call, Response<DelKategoriResp> response) {
                Intent intent = new Intent(context, KategoriMenuWarungActivity.class);
                context.startActivity(intent);
            }

            @Override
            public void onFailure(Call<DelKategoriResp> call, Throwable t) {
                Log.d("gagal", "dihapus");
            }
        });
    }

    @Override
    public int getItemCount() {
        return kategoriMenuList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvKategori;
        CircleImageView ivEditKategori, ivEditKategori1;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvKategori = itemView.findViewById(R.id.tvKategori);
            ivEditKategori = itemView.findViewById(R.id.ivEditKategori);
            ivEditKategori1 = itemView.findViewById(R.id.ivEditKategori2);
        }
    }
}
