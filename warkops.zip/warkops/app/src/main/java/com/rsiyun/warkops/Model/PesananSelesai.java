package com.rsiyun.warkops.Model;

import com.google.gson.annotations.SerializedName;

public class PesananSelesai {
    @SerializedName("idorder")
    private Integer idorder;
    @SerializedName("idwarkop")
    private Integer idwarkop;
    @SerializedName("tglorder")
    private String tgl;
    @SerializedName("status")
    private Integer status;
    @SerializedName("total")
    private String total;
    @SerializedName("namawarung")
    private String namaWarung;
    @SerializedName("notelp")
    private String noTelp;
    @SerializedName("rating")
    private Double rating;
    @SerializedName("imgwarkop")
    private String imgWarkop;

    public PesananSelesai(Integer idorder, Integer idwarkop, String tgl, Integer status, String total, String namaWarung, String noTelp, Double rating, String imgWarkop) {
        this.idorder = idorder;
        this.idwarkop = idwarkop;
        this.tgl = tgl;
        this.status = status;
        this.total = total;
        this.namaWarung = namaWarung;
        this.noTelp = noTelp;
        this.rating = rating;
        this.imgWarkop = imgWarkop;
    }

    public Integer getIdorder() {
        return idorder;
    }

    public void setIdorder(Integer idorder) {
        this.idorder = idorder;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    public Integer getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(Integer idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getNamaWarung() {
        return namaWarung;
    }

    public void setNamaWarung(String namaWarung) {
        this.namaWarung = namaWarung;
    }

    public String getImgWarkop() {
        return imgWarkop;
    }

    public void setImgWarkop(String imgWarkop) {
        this.imgWarkop = imgWarkop;
    }

    public Double getRating() {
        return rating;
    }

    public void setNamaWarung(Double rating) {
        this.rating = rating;
    }
}
