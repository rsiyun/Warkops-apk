package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.Get.LoginRequest;
import com.rsiyun.warkops.Get.LoginWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginWarungActivity extends AppCompatActivity {
    LinearLayout register, login;
    EditText etUsername, etPassword;
    ApiInterface apiInterface;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String sessionW = "SessionW";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_warung);
        load();
        getSupportActionBar().hide();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterWarungActivity();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etUsername.getText().toString())){
                    etUsername.setError("Username anda harus diisi");
                    etUsername.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(etPassword.getText().toString())){
                    etPassword.setError("Password harus diisi");
                    etPassword.requestFocus();
                }else{
                    login();
                }
            }
        });
    }
    public void login(){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(etUsername.getText().toString());
        loginRequest.setPassword(etPassword.getText().toString());
        Call<LoginWarkop> call = apiInterface.getDataLoginW(loginRequest);
        call.enqueue(new Callback<LoginWarkop>() {
            @Override
            public void onResponse(Call<LoginWarkop> call, Response<LoginWarkop> response) {
                if (response.body() == null){
                    Toast.makeText(LoginWarungActivity.this, "Username/Password Salah", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(LoginWarungActivity.this, "Login Successful", Toast.LENGTH_LONG).show();
                    pref = getSharedPreferences(sessionW, MODE_PRIVATE);
                    editor = pref.edit();
                    editor.putInt("idwarkop", response.body().getIdwarkop());
                    editor.putString("username", response.body().getUsername());
                    editor.putString("namaWarung", response.body().getNamawarung());
                    editor.putString("namaPengguna", response.body().getNamaPengguna());
                    editor.putString("noTelp", response.body().getNoTelp());
                    editor.putString("imgWarkop", response.body().getImgWarkop());
                    editor.putString("rating", response.body().getRating());
                    editor.apply();
                    PembayaranWarungActivity();
                }
            }

            @Override
            public void onFailure(Call<LoginWarkop> call, Throwable t) {
                Toast.makeText(LoginWarungActivity.this, "Username/Password Salah", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void load(){
        register = findViewById(R.id.registerWarung);
        login = findViewById(R.id.loginWarung);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
    public void RegisterWarungActivity(){
        Intent intent = new Intent(this, RegisterWarungActivity.class);
        startActivity(intent);
    }
    public void PembayaranWarungActivity(){
        Intent intent = new Intent(this, PembayaranWarungActivity.class);
        startActivity(intent);
    }

}