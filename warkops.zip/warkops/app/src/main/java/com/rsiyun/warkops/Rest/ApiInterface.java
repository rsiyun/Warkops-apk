package com.rsiyun.warkops.Rest;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Get.DelKategoriResp;
import com.rsiyun.warkops.Get.GantiPasswordPembeli;
import com.rsiyun.warkops.Get.GetDetail;
import com.rsiyun.warkops.Get.GetKategoriMenu;
import com.rsiyun.warkops.Get.GetMenu;
import com.rsiyun.warkops.Get.GetPelangganUsername;
import com.rsiyun.warkops.Get.GetPesanan;
import com.rsiyun.warkops.Get.GetPesananSelesai;
import com.rsiyun.warkops.Get.GetPesananWarkop;
import com.rsiyun.warkops.Get.GetWarkop;
import com.rsiyun.warkops.Get.LoginPelanggan;
import com.rsiyun.warkops.Get.LoginRequest;
import com.rsiyun.warkops.Get.LoginWarkop;
import com.rsiyun.warkops.Get.CariUsernamePembeliReq;
import com.rsiyun.warkops.Get.RegisterPembeliReq;
import com.rsiyun.warkops.Get.TambahDetail;
import com.rsiyun.warkops.Get.TambahKategori;
import com.rsiyun.warkops.Get.TambahMenu;
import com.rsiyun.warkops.Get.TambahMenuGambar;
import com.rsiyun.warkops.Get.TambahOrder;
import com.rsiyun.warkops.Get.UbahGambarPelanggan;
import com.rsiyun.warkops.Get.UbahPelanggan;
import com.rsiyun.warkops.Model.Paket;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface ApiInterface {
    @GET("api/warkop")
    Call<GetWarkop> getWarkop();

    @GET("api/kategori/{id}")
    Call<GetKategoriMenu> getKategoriOne(@Path("id") String id);
    @DELETE("api/kategori/{id}")
    Call<DelKategoriResp> deleteKategori(@Path("id") String id);
    @DELETE("api/menu/{id}")
    Call<DelKategoriResp> deleteMenu(@Path("id") String id);
    @GET("api/kategori")
    Call<GetKategoriMenu> getKategori();
    @GET("api/menu/{id}")
    Call<GetMenu> getMenu(@Path("id") String id);

    @GET("api/order/{id}")
    Call<GetPesanan> getPesanan(@Path("id") String id);
    @GET("api/orderSelesai/{id}")
    Call<GetPesananSelesai> getPesananSelesai(@Path("id") String id);
    @GET("api/orderW/{id}")
    Call<GetPesananWarkop> getPesananWarkop(@Path("id") String id);
    @GET("api/orderSelesaiW/{id}")
    Call<GetPesananWarkop> getPesananWarkopSelesai(@Path("id") String id);
    @GET("api/orderD/{id}")
    Call<GetPesananWarkop> getidOrder(@Path("id") String id);


    @GET("api/detail/{id}")
    Call<GetDetail> getDetail(@Path("id") String id);


    @POST("api/loginpelanggan")
    Call<LoginPelanggan> getDataLogin(@Body LoginRequest loginRequest);
    @POST("api/loginwarkop")
    Call<LoginWarkop> getDataLoginW(@Body LoginRequest loginRequest);
    @POST("api/lppelanggan/{id}")
    Call<GantiPasswordPembeli> gantiPasswordPembeli(@Path("id") String id,
                                                    @Body GantiPasswordPembeli gantiPasswordPembeli);
    @POST("api/pelangganCari")
    Call<GetPelangganUsername> getDataPelanggan(@Body CariUsernamePembeliReq cariUsernamePembeliReq);
    @POST("api/kategori")
    Call<TambahKategori> TambahKat(@Body TambahKategori tambahKategori);

    @POST("api/menu")
    Call<TambahMenu> TambahMenu(@Body TambahMenu tambahMenu);
    @POST("api/menuG/{id}")
    @Multipart
    Call<TambahMenuGambar> TambahMenuGambar(@Path("id") String id,
                                            @Part MultipartBody.Part imgmenu);

    @POST("api/pelangganG/{id}")
    @Multipart
    Call<UbahGambarPelanggan> UbahGambarPelanggan(@Path("id") String id, @Part MultipartBody.Part imgpelanggan);

    @POST("api/pelanggan/{id}")
    Call<UbahPelanggan> ubahPelanggan(@Path("id") String id, @Body UbahPelanggan ubahPelanggan);
    @POST("api/registerpelanggan")
    Call<RegisterPembeliReq> RegisterPembeli(@Body RegisterPembeliReq registerPembeliReq);

    @POST("api/order")
    Call<TambahOrder> TambahOrder(@Body TambahOrder tambahOrder);
    @POST("api/detail")
    Call<TambahDetail> TambahDetail(@Body TambahDetail tambahDetail);

    @GET("api/paket")
    Call<List<Paket>> getPaket();
}
