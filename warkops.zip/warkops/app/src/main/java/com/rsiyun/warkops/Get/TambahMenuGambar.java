package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class TambahMenuGambar {
    @SerializedName("imgmenu")
    private String imgmenu;

    public String getImgmenu() {
        return imgmenu;
    }

    public void setImgmenu(String imgmenu) {
        this.imgmenu = imgmenu;
    }
}
