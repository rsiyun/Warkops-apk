package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PesananWarkop {
    @SerializedName("idorder")
    @Expose
    private Integer idorder;
    @SerializedName("idwarkop")
    @Expose
    private Integer idwarkop;
    @SerializedName("idpelanggan")
    @Expose
    private Integer idpelanggan;
    @SerializedName("tglorder")
    @Expose
    private String tglorder;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("total")
    @Expose
    private Integer total;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("alamat")
    @Expose
    private String alamat;
    @SerializedName("notelp")
    private String notelp;
    @SerializedName("imgpelanggan")
    private String imgPelanggan;

    public PesananWarkop(Integer idorder, Integer idwarkop, Integer idpelanggan, String tglorder, Integer status, Integer total, String username, String alamat, String notelp, String imgPelanggan) {
        this.idorder = idorder;
        this.idwarkop = idwarkop;
        this.idpelanggan = idpelanggan;
        this.tglorder = tglorder;
        this.status = status;
        this.total = total;
        this.username = username;
        this.alamat = alamat;
        this.notelp = notelp;
        this.imgPelanggan = imgPelanggan;
    }

    public Integer getIdorder() {
        return idorder;
    }

    public void setIdorder(Integer idorder) {
        this.idorder = idorder;
    }

    public Integer getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(Integer idwarkop) {
        this.idwarkop = idwarkop;
    }

    public Integer getIdpelanggan() {
        return idpelanggan;
    }

    public void setIdpelanggan(Integer idpelanggan) {
        this.idpelanggan = idpelanggan;
    }

    public String getTglorder() {
        return tglorder;
    }

    public void setTglorder(String tglorder) {
        this.tglorder = tglorder;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNotelp() {
        return notelp;
    }

    public void setNotelp(String notelp) {
        this.notelp = notelp;
    }

    public String getImgPelanggan() {
        return imgPelanggan;
    }

    public void setImgPelanggan(String imgPelanggan) {
        this.imgPelanggan = imgPelanggan;
    }
}
