package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class UbahGambarPelanggan {
    @SerializedName("imgpelanggan")
    private String imgpelanggan;

    public String getImgpelanggan() {
        return imgpelanggan;
    }

    public void setImgpelanggan(String imgpelanggan) {
        this.imgpelanggan = imgpelanggan;
    }
}
