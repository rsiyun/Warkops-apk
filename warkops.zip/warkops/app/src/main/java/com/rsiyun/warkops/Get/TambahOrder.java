package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class TambahOrder {
    @SerializedName("id")
    private String id;
    @SerializedName("idwarkop")
    private String idwarkop;
    @SerializedName("idpelanggan")
    private String idpelanggan;
    @SerializedName("tglorder")
    private String tglorder;
    @SerializedName("status")
    private String status;
    @SerializedName("total")
    private String total;

    public TambahOrder(String idwarkop, String idpelanggan, String tglorder, String status, String total) {
        this.idwarkop = idwarkop;
        this.idpelanggan = idpelanggan;
        this.tglorder = tglorder;
        this.status = status;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(String idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getIdpelanggan() {
        return idpelanggan;
    }

    public void setIdpelanggan(String idpelanggan) {
        this.idpelanggan = idpelanggan;
    }

    public String getTglorder() {
        return tglorder;
    }

    public void setTglorder(String tglorder) {
        this.tglorder = tglorder;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
