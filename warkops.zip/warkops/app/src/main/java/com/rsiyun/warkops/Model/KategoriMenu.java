package com.rsiyun.warkops.Model;


import com.google.gson.annotations.SerializedName;

public class KategoriMenu {
    @SerializedName("idkategori")
    private String idkategori;
    @SerializedName("idwarkop")
    private String idwarkop;
    @SerializedName("kategori")
    private String Kategori;

    public KategoriMenu(String idkategori, String idwarkop, String kategori) {
        this.idkategori = idkategori;
        this.idwarkop = idwarkop;
        Kategori = kategori;
    }

    public String getIdkategori() {
        return idkategori;
    }

    public void setIdkategori(String idkategori) {
        this.idkategori = idkategori;
    }

    public String getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(String idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getKategori() {
        return Kategori;
    }

    public void setKategori(String kategori) {
        Kategori = kategori;
    }
}
