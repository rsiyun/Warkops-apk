package com.rsiyun.warkops.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.rsiyun.warkops.Get.GetKategoriMenu;
import com.rsiyun.warkops.Get.GetPesanan;
import com.rsiyun.warkops.Get.TambahMenu;
import com.rsiyun.warkops.Get.TambahMenuGambar;
import com.rsiyun.warkops.Model.KategoriMenu;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TambahMenuActivity extends AppCompatActivity {
    Toolbar toolbar;
    Spinner spKategoriMenu, spStatus;
    EditText etBarang, etHarga, etDeskripsi;
    ApiInterface apiInterface;
    Integer idWarkop;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    LinearLayout tambahGambar, btnTambahMenu;
    File file;
    List<String> listSpinner;
    ArrayList<String> statusList, idkategori;

    public static final String sessionW = "SessionW";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_menu);
        load();
        toolbar();
        kategoriSpinner();
        adaAtauTakAda();
        tambahGambar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImagePicker.with(TambahMenuActivity.this).crop().maxResultSize(1080, 1080).start();
            }
        });
        btnTambahMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etBarang.getText().toString())){
                    etBarang.setError("Username anda harus diisi");
                    etBarang.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(etDeskripsi.getText().toString())){
                    etHarga.setError("Password harus diisi");
                    etHarga.requestFocus();
                }
                else if (TextUtils.isEmpty(etHarga.getText().toString())){
                    etHarga.setError("Password harus diisi");
                    etHarga.requestFocus();
                }
                else if (listSpinner.get(0).toString().equals(spKategoriMenu.getSelectedItem().toString())){
                    ((TextView)spKategoriMenu.getSelectedView()).setError("Pilih kategori dulu");
                }
                else if (statusList.get(0).toString().equals(spStatus.getSelectedItem().toString())){
                    ((TextView)spStatus.getSelectedView()).setError("Pilih Status dulu");
                }
                else{
                    MediaType contentType;
                    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
                    MultipartBody.Part filePart = MultipartBody.Part.createFormData("imgmenu", file.getName(), requestFile);
//                    MediaType contentType;
                    String status;
                    spKategoriMenu.getSelectedItem().toString();
                    String[] nilai = spKategoriMenu.getSelectedItem().toString().split(" ");
                    if (spStatus.getSelectedItem().toString().equals("Habis")){
                        status = "0";
                        TambahMenu Body = new TambahMenu(nilai[1],etBarang.getText().toString(),etDeskripsi.getText().toString(),etHarga.getText().toString(),status);
                        Call<TambahMenu> call = apiInterface.TambahMenu(Body);
                        call.enqueue(new Callback<TambahMenu>() {
                            @Override
                            public void onResponse(Call<TambahMenu> call, Response<TambahMenu> response) {
                               if (response.body().getIdmenu().isEmpty()){
                                   Toast.makeText(TambahMenuActivity.this, "input gagal", Toast.LENGTH_SHORT).show();
                               }else{
                                   Call<TambahMenuGambar> menuG = apiInterface.TambahMenuGambar(response.body().getIdmenu(), filePart);
                                   menuG.enqueue(new Callback<TambahMenuGambar>() {
                                       @Override
                                       public void onResponse(Call<TambahMenuGambar> call, Response<TambahMenuGambar> response) {
                                           Toast.makeText(TambahMenuActivity.this, "masuk dengan gambar", Toast.LENGTH_SHORT).show();
                                       }

                                       @Override
                                       public void onFailure(Call<TambahMenuGambar> call, Throwable t) {
                                           Toast.makeText(TambahMenuActivity.this, "Masuk gaes Tanpa Gambar 2", Toast.LENGTH_SHORT).show();
                                       }
                                   });
                               }
                            }

                            @Override
                            public void onFailure(Call<TambahMenu> call, Throwable t) {

                            }
                        });
                    }else if(spStatus.getSelectedItem().toString().equals("Ada")){
                        status = "1";
                        TambahMenu Body = new TambahMenu(nilai[1],etBarang.getText().toString(),etDeskripsi.getText().toString(),etHarga.getText().toString(),status);
                        Call<TambahMenu> call = apiInterface.TambahMenu(Body);
                        call.enqueue(new Callback<TambahMenu>() {
                            @Override
                            public void onResponse(Call<TambahMenu> call, Response<TambahMenu> response) {
                                if (response.body().getIdmenu().isEmpty()){
                                    Toast.makeText(TambahMenuActivity.this, "input gagal", Toast.LENGTH_SHORT).show();
                                }else{
                                    Call<TambahMenuGambar> menuG =apiInterface.TambahMenuGambar(response.body().getIdmenu(), filePart);
                                    menuG.enqueue(new Callback<TambahMenuGambar>() {
                                        @Override
                                        public void onResponse(Call<TambahMenuGambar> call, Response<TambahMenuGambar> response) {
                                            Toast.makeText(TambahMenuActivity.this, "masuk dengan gambar", Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onFailure(Call<TambahMenuGambar> call, Throwable throwable) {
                                            Toast.makeText(TambahMenuActivity.this, "masuk tanpa Gambar", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onFailure(Call<TambahMenu> call, Throwable throwable) {

                            }
                        });
                    }else{
                        Toast.makeText(TambahMenuActivity.this, "Data tidak masuk", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarTambahMenu);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void load(){
        pref = getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        spKategoriMenu = findViewById(R.id.spKategoriMenu);
        spStatus = findViewById(R.id.spStatus);
        etBarang = findViewById(R.id.etBarang);
        etHarga = findViewById(R.id.etHarga);
        etDeskripsi = findViewById(R.id.etDeskripsi);
        tambahGambar = findViewById(R.id.tambahGambar);
        btnTambahMenu = findViewById(R.id.btnTambahMenu);
        idWarkop = pref.getInt("idwarkop",0);
    }

    public void kategoriSpinner() {
        apiInterface.getKategoriOne(""+idWarkop).enqueue(new Callback<GetKategoriMenu>() {
            @Override
            public void onResponse(Call<GetKategoriMenu> call, Response<GetKategoriMenu> response) {
                if (response.isSuccessful()){
                    List<KategoriMenu> kategoriMenuList = response.body().getKategoriMenuList();
                    listSpinner = new ArrayList<>();
                    idkategori = new ArrayList<>();
                    for (int i = 0; i<kategoriMenuList.size(); i++){
                        listSpinner.add(kategoriMenuList.get(i).getKategori()+" "+kategoriMenuList.get(i).getIdkategori());
                    }
                    listSpinner.add(0,"kategori");
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(TambahMenuActivity.this, android.R.layout.simple_spinner_item, listSpinner);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spKategoriMenu.setAdapter(adapter);

                }else{
                    Toast.makeText(TambahMenuActivity.this, "Gagal", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetKategoriMenu> call, Throwable t) {
                Toast.makeText(TambahMenuActivity.this, "Internet", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void adaAtauTakAda(){
        statusList = new ArrayList<>();
        statusList.add(0, "Status Habis/Ada");
        statusList.add("Habis");
        statusList.add("Ada");
        ArrayAdapter<String> StatusAdapter;
        StatusAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statusList);
        StatusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spStatus.setAdapter(StatusAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();
            file = new File(uri.getPath());
        }

    }
}