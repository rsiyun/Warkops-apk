package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class RegisterPembeliReq {
    @SerializedName("username")
    private String username;
    @SerializedName("namapengguna")
    private String namaPengguna;
    @SerializedName("notelp")
    private String noTelp;
    @SerializedName("password")
    private String password;

    public RegisterPembeliReq(String username, String namaPengguna, String noTelp, String password) {
        this.username = username;
        this.namaPengguna = namaPengguna;
        this.noTelp = noTelp;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamaPengguna() {
        return namaPengguna;
    }

    public void setNamaPengguna(String namaPengguna) {
        this.namaPengguna = namaPengguna;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
