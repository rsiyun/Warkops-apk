package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.R;

public class UbahKategoriMenuActivity extends AppCompatActivity {
    Toolbar toolbar;
    EditText etKategoriMenu;
    String idkategori;
    LinearLayout btnUbah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_kategori_menu);
        toolbar();
        load();
        btnUbah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etKategoriMenu.getText().toString())){
                    etKategoriMenu.setError("Username anda harus diisi");
                    etKategoriMenu.requestFocus();
                }
                else{
                    ubahKategori(idkategori);
                }
            }
        });
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarUbahKategori);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void ubahKategori(String idkategori){
        Toast.makeText(this, idkategori, Toast.LENGTH_SHORT).show();
    }
    public void load(){
        etKategoriMenu = findViewById(R.id.etKategoriMenu);
        idkategori = getIntent().getStringExtra("idkategori");
        btnUbah = findViewById(R.id.btnUbahKat);
    }
}