package com.rsiyun.warkops.Model;

public class DetailPesananWarkop {
    private String NamaMenu, Harga, Jumlah;

    public DetailPesananWarkop(String namaMenu, String harga, String jumlah) {
        NamaMenu = namaMenu;
        Harga = harga;
        Jumlah = jumlah;
    }

    public String getJumlah(){
        return Jumlah;
    }
    public void setJumlah(String jumlah){
        Jumlah = jumlah;
    }

    public String getNamaMenu() {
        return NamaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        NamaMenu = namaMenu;
    }

    public String getHarga() {
        return Harga;
    }

    public void setHarga(String harga) {
        Harga = harga;
    }
}
