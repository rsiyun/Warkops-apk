package com.rsiyun.warkops.Model;

public class MenuWarkop {
    private String namaMenu, Harga;

    public MenuWarkop(String namaMenu, String harga) {
        this.namaMenu = namaMenu;
        this.Harga = harga;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public String getHarga() {
        return Harga;
    }

    public void setHarga(String harga) {
        Harga = harga;
    }
}
