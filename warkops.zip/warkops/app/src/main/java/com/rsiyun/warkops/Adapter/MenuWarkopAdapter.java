package com.rsiyun.warkops.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.UbahMenuActivity;
import com.rsiyun.warkops.Get.DelKategoriResp;
import com.rsiyun.warkops.Model.Menu;
import com.rsiyun.warkops.Model.MenuWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuWarkopAdapter extends RecyclerView.Adapter<MenuWarkopAdapter.ViewHolder>{
    Context context;
    List<Menu> menuWarkopList;
    ApiInterface apiInterface;
    public MenuWarkopAdapter(Context context, List<Menu> menuWarkopList) {
        this.context = context;
        this.menuWarkopList = menuWarkopList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu_warkop,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Menu menuWarkop = menuWarkopList.get(position);
        holder.tvNamaMenu.setText(menuWarkop.getMenu());
        holder.tvHarga.setText(menuWarkop.getHarga());
        Glide.with(context).load(""+menuWarkop.getImgmenu()).into(holder.ivGambar);
        holder.btnUbahMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UbahMenuActivity.class);
                context.startActivity(intent);
            }
        });
        holder.btnHapusMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(context)
                        .setIcon(R.mipmap.ic_launcher)
                        .setTitle("Hapus "+ menuWarkop.getMenu())
                        .setMessage("apakah anda yakin ingin menghapus menu tersebut ?")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                hapusMenu(menuWarkop.getIdmenu().toString(),position);
                            }
                        })
                        .setNegativeButton("Batalkan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();
            }
        });
    }
    public void removeAt(int position){
        menuWarkopList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, menuWarkopList.size());
    }
    public void hapusMenu(String idmenu, int position){
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<DelKategoriResp> deleteMenu = apiInterface.deleteMenu(idmenu);
        deleteMenu.enqueue(new Callback<DelKategoriResp>() {
            @Override
            public void onResponse(Call<DelKategoriResp> call, Response<DelKategoriResp> response) {
                Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                removeAt(position);
            }

            @Override
            public void onFailure(Call<DelKategoriResp> call, Throwable throwable) {
                
            }
        });

    }

    @Override
    public int getItemCount() {
        return menuWarkopList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaMenu, tvHarga;
        ImageView ivGambar;
        CircleImageView btnHapusMenu, btnUbahMenu;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaMenu = itemView.findViewById(R.id.tvNamaMenuWarkop);
            tvHarga = itemView.findViewById(R.id.tvHargaWarkop);
            ivGambar = itemView.findViewById(R.id.ivGambar);
            btnHapusMenu = itemView.findViewById(R.id.btnHapusMenu);
            btnUbahMenu = itemView.findViewById(R.id.btnUbahMenu);
        }
    }
}
