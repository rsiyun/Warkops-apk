package com.rsiyun.warkops.Model;

public class PesananWarkopSelesai {
    private String NamaPembeli, jamSelesai, status, tgl;

    public PesananWarkopSelesai(String namaPembeli, String jamSelesai, String status, String tgl) {
        NamaPembeli = namaPembeli;
        this.jamSelesai = jamSelesai;
        this.status = status;
        this.tgl = tgl;
    }

    public String getNamaPembeli() {
        return NamaPembeli;
    }

    public void setNamaPembeli(String namaPembeli) {
        NamaPembeli = namaPembeli;
    }

    public String getJamSelesai() {
        return jamSelesai;
    }

    public void setJamSelesai(String jamSelesai) {
        this.jamSelesai = jamSelesai;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTgl(){return tgl;}

    public void setTgl(String tgl){this.tgl = tgl;}
}
