package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class TambahKategori {
    @SerializedName("idwarkop")
    private Integer idwarkop;
    @SerializedName("kategori")
    private String kategori;

    public TambahKategori(Integer idwarkop, String kategori) {
        this.idwarkop = idwarkop;
        this.kategori = kategori;
    }

    public Integer getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(Integer idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }
}
