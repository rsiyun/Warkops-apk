package com.rsiyun.warkops.Fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.LoginPembeliActivity;
import com.rsiyun.warkops.Activity.LoginWarungActivity;
import com.rsiyun.warkops.Activity.MainActivity;
import com.rsiyun.warkops.Activity.MainMenuWarungActivity;
import com.rsiyun.warkops.Activity.PemilihanLoginActivity;
import com.rsiyun.warkops.Activity.RegisterWarungActivity;
import com.rsiyun.warkops.Activity.UbahProfileActivity;
import com.rsiyun.warkops.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AkunFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AkunFragment extends Fragment {
    View rootView;
    ImageView btnUbahProfil;
    CardView btnKeluar, btnWarung;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String session = "Session";
    TextView tvUsername, tvNamaPengguna,tvNoTelp;
    CircleImageView ivFotoPembeli;
    Integer id;
    String username,namaPengguna,imgPelanggan,noTelp;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AkunFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AkunFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AkunFragment newInstance(String param1, String param2) {
        AkunFragment fragment = new AkunFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    public void getSession(){
        pref = getContext().getSharedPreferences(session, Context.MODE_PRIVATE);
        id = pref.getInt("idPelanggan",0);
        username = pref.getString("username","");
        namaPengguna = pref.getString("namaPengguna","");
        imgPelanggan = pref.getString("imgPelanggan","");
        noTelp = pref.getString("noTelp", "");
    }
    public void load(){
//        btnDaftarAkunWarung = rootView.findViewById(R.id.btnDaftarAkunWarung);
        btnUbahProfil = rootView.findViewById(R.id.btnUbahProfil);
        btnKeluar = rootView.findViewById(R.id.Keluar);
        btnWarung = rootView.findViewById(R.id.Warung);
        tvNamaPengguna = rootView.findViewById(R.id.tvNamaPengguna);
        tvNoTelp = rootView.findViewById(R.id.tvNoTelp);
        tvUsername = rootView.findViewById(R.id.tvUsername);
        ivFotoPembeli = rootView.findViewById(R.id.ivFotoPembeli);
        getSession();
        if (id==0){
            Intent intent = new Intent(getActivity(), PemilihanLoginActivity.class);
            startActivity(intent);
        }else {
            tvUsername.setText(username);
            tvNamaPengguna.setText(namaPengguna);
            tvNoTelp.setText(noTelp);
            Glide.with(getContext()).load(""+imgPelanggan).circleCrop().into(ivFotoPembeli);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ((MainActivity) getActivity()).getSupportActionBar().hide();
        rootView = inflater.inflate(R.layout.fragment_akun, container, false);
        load();
        btnWarung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getActivity()).setTitle(R.string.app_name)
                        .setIcon(R.mipmap.ic_launcher)
                        .setMessage("Login Ke Akun Warung ?")
                        .setPositiveButton("Lanjutkan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                pref.edit().clear().commit();
                                LoginWarungActivity();
                            }
                        }).setNegativeButton("Batalkan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).show();
            }
        });
        btnKeluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getActivity()).setTitle(R.string.app_name)
                        .setIcon(R.mipmap.ic_launcher)
                        .setMessage("Apakah Anda Yakin Untuk Keluar")
                        .setPositiveButton("Lanjutkan", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                pref.edit().clear().commit();
                                Toast.makeText(getActivity(), "Logout", Toast.LENGTH_SHORT).show();
                                Fragment fragment = null;
                                fragment = new Home();
                                replaceFragment(fragment);
                            }
                        }).setNegativeButton("Batalkan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).show();
            }
        });
        btnUbahProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    UbahProfileActivity();
            }
        });
        return rootView;
    }
    public void UbahProfileActivity(){
        Intent intent = new Intent(getActivity(), UbahProfileActivity.class);
        startActivityForResult(intent, 10);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("lalalala", requestCode+"");
        getSession();
        load();
    }

    public void LoginWarungActivity(){
        Intent intent = new Intent(getActivity(), LoginWarungActivity.class);
        startActivity(intent);
    }
    public void replaceFragment(Fragment someFragment){
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, someFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}