package com.rsiyun.warkops.Adapter;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Activity.CartPembeliActivity;
import com.rsiyun.warkops.Activity.DetailPesananActivity;
import com.rsiyun.warkops.Model.Pesanan;
import com.rsiyun.warkops.R;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PesananAdapter extends RecyclerView.Adapter<PesananAdapter.ViewHolder> {
    private Context context;
    private List<Pesanan> pesananList;

    public PesananAdapter(Context context, List<Pesanan> pesananList) {
        this.context = context;
        this.pesananList = pesananList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Pesanan pesanan = pesananList.get(position);
        holder.tvNamaWarkop.setText(pesanan.getNamaWarung());
        holder.tvTgl.setText(pesanan.getTgl());
//        holder.btnTelp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                makeCall(position);
//            }
//        });
        Glide.with(context).load(""+pesanan.getImgWarkop()).into(holder.ivGambar);
        if (pesanan.getStatus().equals(1)) {
            holder.tvStatus.setText("Pesanan Sedang disiapkan");
        }else if (pesanan.getStatus().equals(2)){
            holder.tvStatus.setText("Pesanan Sedang diantar");
        }else{
            holder.itemView.setVisibility(View.INVISIBLE);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailPesananActivity.class);
                intent.putExtra("idorder", pesananList.get(position).getIdorder());
                intent.putExtra("namawarung", pesananList.get(position).getNamaWarung());
                intent.putExtra("status", pesananList.get(position).getStatus());
                intent.putExtra("tgl", pesananList.get(position).getTgl());
                intent.putExtra("notelp", "+62"+pesananList.get(position).getNoTelp());
                intent.putExtra("total", pesananList.get(position).getTotal());
                intent.putExtra("rating", pesananList.get(position).getRating());
                intent.putExtra("imgwarkop", pesananList.get(position).getImgWarkop());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pesananList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaWarkop, tvJam, tvStatus, tvTgl;
        CircleImageView ivGambar;
        ImageView btnTelp;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaWarkop = itemView.findViewById(R.id.tvNamaWarkop);
            tvJam = itemView.findViewById(R.id.tvJam);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvTgl = itemView.findViewById(R.id.tvtgl);
            ivGambar = itemView.findViewById(R.id.ivGambar);
//            btnTelp = itemView.findViewById(R.id.btntelp);
        }
    }
//    private void makeCall(int position){
//        if (pesananList.get(position).getNoTelp().trim().length() > 0){
//            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
//                ActivityCompat.requestPermissions(context, new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
//            }else{
//                String dial = "tel:"+pesananList.get(position).getNoTelp();
//                context.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
//            }
//        }else{
//            Toast.makeText(context, "nomer anda kosong", Toast.LENGTH_SHORT).show();
//        }
//    }

}
