package com.rsiyun.warkops.Model;

public class Cart {
    private String IdCart;
    private String Idmenu;
    private String NamaMenu;
    private String Harga;
    private String Jumlah;
    private String Gambar;

    public Cart(String idcart ,String idmenu ,String namaMenu, String harga, String jumlah, String gambar) {
        IdCart = idcart;
        Idmenu = idmenu;
        NamaMenu = namaMenu;
        Harga = harga;
        Jumlah = jumlah;
        Gambar = gambar;
    }
    public String getIdCart() {
        return IdCart;
    }

    public void setIdCart(String idcart) {
        IdCart = idcart;
    }
    public String getIdmenu() {
        return Idmenu;
    }

    public void setIdmenu(String idmenu) {
        Idmenu = idmenu;
    }

    public String getNamaMenu() {
        return NamaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        NamaMenu = namaMenu;
    }

    public String getHarga() {
        return Harga;
    }

    public void setHarga(String harga) {
        Harga = harga;
    }

    public String getJumlah() {
        return Jumlah;
    }

    public void setJumlah(String jumlah) {
        Jumlah = jumlah;
    }

    public String getGambar() {
        return Gambar;
    }

    public void setGambar(String gambar) {
        Gambar = gambar;
    }
}
