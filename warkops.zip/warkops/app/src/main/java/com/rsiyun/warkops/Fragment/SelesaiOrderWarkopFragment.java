package com.rsiyun.warkops.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.rsiyun.warkops.Adapter.PesananWarkopSelesaiAdapter;
import com.rsiyun.warkops.Get.GetPesanan;
import com.rsiyun.warkops.Get.GetPesananWarkop;
import com.rsiyun.warkops.Model.PesananWarkop;
import com.rsiyun.warkops.Model.PesananWarkopSelesai;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SelesaiOrderWarkopFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SelesaiOrderWarkopFragment extends Fragment implements View.OnClickListener{
    View rootView;
    RecyclerView recyclerView;
    Button btnSedangBerlangsung;
    PesananWarkopSelesaiAdapter adapter;
    List<PesananWarkop> pesananWarkopSelesaiList;
    Integer idWarkop;
    ApiInterface apiInterface;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String sessionW = "SessionW";
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SelesaiOrderWarkopFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SelesaiOrderWarkopFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SelesaiOrderWarkopFragment newInstance(String param1, String param2) {
        SelesaiOrderWarkopFragment fragment = new SelesaiOrderWarkopFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    public void load(){
        recyclerView = rootView.findViewById(R.id.rcvSelesaiPesananWarkop);
        btnSedangBerlangsung = rootView.findViewById(R.id.btnBerlangsungWarkop);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getContext().getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        idWarkop = pref.getInt("idwarkop",0);
    }
    public void isiData(){
        Call<GetPesananWarkop> call = apiInterface.getPesananWarkopSelesai(""+idWarkop);
        call.enqueue(new Callback<GetPesananWarkop>() {
            @Override
            public void onResponse(Call<GetPesananWarkop> call, Response<GetPesananWarkop> response) {
                pesananWarkopSelesaiList = response.body().getPesananWarkopList();
                if (pesananWarkopSelesaiList.size()==0){
                    Toast.makeText(getActivity(), "Data Kosong", Toast.LENGTH_SHORT).show();
                }{
                    Log.d("Retrofit Get", "Jumlah data Kontak: " +
                            String.valueOf(pesananWarkopSelesaiList.size()));
                    adapter = new PesananWarkopSelesaiAdapter(getActivity(), pesananWarkopSelesaiList);
                    recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<GetPesananWarkop> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_selesai_order_warkop, container, false);
        load();
        isiData();
        btnSedangBerlangsung.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onClick(View v) {
        Fragment fragment = null;
        switch (v.getId()){
            case R.id.btnBerlangsungWarkop:
                fragment = new PesananWarkopFragment();
                replaceFragment(fragment);
        }
    }
    public void replaceFragment(Fragment someFragment){
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container_warung, someFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}