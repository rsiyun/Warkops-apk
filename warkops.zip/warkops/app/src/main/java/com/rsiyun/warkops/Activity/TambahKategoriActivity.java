package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.rsiyun.warkops.Get.TambahKategori;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TambahKategoriActivity extends AppCompatActivity {
    Toolbar toolbar;
    EditText etKategori;
    Integer idWarkop;
    ApiInterface apiInterface;
    SharedPreferences pref;
    public static final String sessionW = "SessionW";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_kategori);
        load();
        toolbar();
    }
    public void load(){
        etKategori = findViewById(R.id.etKategoriMenu);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        idWarkop = pref.getInt("idwarkop",0);
    }
    public void toolbar(){
     toolbar = findViewById(R.id.toolbarTambahKategori);
     setSupportActionBar(toolbar);
     toolbar.setNavigationIcon(R.drawable.ic_back);
     toolbar.setNavigationOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             onBackPressed();
         }
     });
    }
    public void tambahKategori(String kategori){
        TambahKategori modal = new TambahKategori(idWarkop, kategori);
        Call<TambahKategori> call = apiInterface.TambahKat(modal);
        call.enqueue(new Callback<TambahKategori>() {
            @Override
            public void onResponse(Call<TambahKategori> call, Response<TambahKategori> response) {
                Toast.makeText(TambahKategoriActivity.this, "Tambah Data Berhasil", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<TambahKategori> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
    public void btnTambahKategori(View view) {
        Intent intent = new Intent(this, KategoriMenuWarungActivity.class);
        String kategori = etKategori.getText().toString();
        if (kategori.isEmpty()){
            Toast.makeText(this, "Katgori tidak boleh kosong", Toast.LENGTH_SHORT).show();
        }else{
            tambahKategori(kategori);
            startActivity(intent);
        }
    }
}