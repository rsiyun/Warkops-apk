package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;

public class LoginWarkop {
    @SerializedName("idwarkop")
    private Integer idwarkop;
    @SerializedName("username")
    private String username;
    @SerializedName("namawarung")
    private String namawarung;
    @SerializedName("namapengguna")
    private String namaPengguna;
    @SerializedName("notelp")
    private String noTelp;
    @SerializedName("imgwarkop")
    private String imgWarkop;
    @SerializedName("rating")
    private String rating;

    public Integer getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(Integer idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamawarung() {
        return namawarung;
    }

    public void setNamawarung(String namawarung) {
        this.namawarung = namawarung;
    }

    public String getNamaPengguna() {
        return namaPengguna;
    }

    public void setNamaPengguna(String namaPengguna) {
        this.namaPengguna = namaPengguna;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    public String getImgWarkop() {
        return imgWarkop;
    }

    public void setImgWarkop(String imgWarkop) {
        this.imgWarkop = imgWarkop;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}
