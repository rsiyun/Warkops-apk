package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Paket {
    @SerializedName("idpaket")
    @Expose
    private Integer idpaket;
    @SerializedName("namapaket")
    @Expose
    private String namapaket;
    @SerializedName("hargapaket")
    @Expose
    private Integer hargapaket;

    public Paket(Integer idpaket, String namapaket, Integer hargapaket) {
        this.idpaket = idpaket;
        this.namapaket = namapaket;
        this.hargapaket = hargapaket;
    }

    public Integer getIdpaket() {
        return idpaket;
    }

    public void setIdpaket(Integer idpaket) {
        this.idpaket = idpaket;
    }

    public String getNamapaket() {
        return namapaket;
    }

    public void setNamapaket(String namapaket) {
        this.namapaket = namapaket;
    }

    public Integer getHargapaket() {
        return hargapaket;
    }

    public void setHargapaket(Integer hargapaket) {
        this.hargapaket = hargapaket;
    }
}
