package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.Warkop;

import java.util.List;

public class  GetWarkop {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<Warkop> listDataWarkop;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Warkop> getListDataWarkop() {
        return listDataWarkop;
    }

    public void setListDataWarkop(List<Warkop> listDataWarkop) {
        this.listDataWarkop = listDataWarkop;
    }
}
