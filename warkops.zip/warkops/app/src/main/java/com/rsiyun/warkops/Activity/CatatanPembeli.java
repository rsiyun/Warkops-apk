package com.rsiyun.warkops.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.rsiyun.warkops.R;

public class CatatanPembeli extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catatan_pembeli);
    }
}
