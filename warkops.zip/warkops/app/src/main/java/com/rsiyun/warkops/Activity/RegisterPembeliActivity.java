package com.rsiyun.warkops.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.rsiyun.warkops.Get.RegisterPembeliReq;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPembeliActivity extends AppCompatActivity {
    EditText etUsername,etNamaPengguna,etPassword,etKonfirmasi,etNotelp, etOtp;
    LinearLayout btnverifyCaptcha, btnRegister, btnOTP;
    private int SELECT_IMAGE_CODE=1;
    private FirebaseAuth mAuth;
    private String verificationId;
    ApiInterface apiInterface;
    String SITE_KEY = "6LeHqlIdAAAAAKnfpka3e4qGgatHCdo0PYmxnNyf";
    String SECRET_KEY = "6LeHqlIdAAAAAN9weniefRehWGupEZUdQ3yzN6ce";
    RequestQueue queue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_pembeli);
        getSupportActionBar().hide();
        mAuth = FirebaseAuth.getInstance();
        load();
        etNotelp.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().length()==1 && s.toString().startsWith("0")){
                    s.clear();
                }
            }
        });
        btnOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etNotelp.getText().toString())){
                    etUsername.setError("No Telp Harus diisi");
                }else{
                    String phone = "+62"+ etNotelp.getText().toString();
                    sendVerification(phone);
                }
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(etUsername.getText().toString())){
                    etUsername.setError("Username anda harus diisi");
                    etUsername.requestFocus();
                    return;
                }
                else if (TextUtils.isEmpty(etNamaPengguna.getText().toString())){
                    etNamaPengguna.setError("Nama anda harus diisi");
                    etNamaPengguna.requestFocus();
                }
                else if (TextUtils.isEmpty(etPassword.getText().toString())||etPassword.length()<8){
                    etPassword.setError("Password harus diisi / minimal 8 karakter");
                    etPassword.requestFocus();
                }
                else if (!isValidPassword(etPassword.getText().toString())){
                    etPassword.setError("Password Minimal 1 huruf kapital, 1 angka, 1 character");
                    etPassword.requestFocus();
                }
                else if (TextUtils.isEmpty(etKonfirmasi.getText().toString())){
                    etKonfirmasi.setError("Konfirmasi harus diisi");
                    etKonfirmasi.requestFocus();
                }
                else if(!etKonfirmasi.getText().toString().equals(etPassword.getText().toString())){
                    etKonfirmasi.setError("Password dan Konfirmasi harus sama");
                    etKonfirmasi.requestFocus();
                }
                else if (TextUtils.isEmpty(etNotelp.getText().toString())){
                    etNotelp.setError("No telp anda harus diisi");
                    etNotelp.requestFocus();
                }else if (TextUtils.isEmpty(etOtp.getText().toString())){
                    etOtp.setError("OTP anda harus Diisi");
                    etOtp.requestFocus();
                }
                else{
                    verifyGoogleReCAPTCHA();
                    verifyCode(etOtp.getText().toString());
                }
            }
        });
    }
    private void sendVerification(String number){
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(mAuth)
                .setPhoneNumber(number)
                .setTimeout(2L, TimeUnit.MINUTES)
                .setActivity(this)
                .setCallbacks(mCallback)
                .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }
    private void verifyCode(String code){
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }
    private void signInWithCredential(PhoneAuthCredential credential){
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(RegisterPembeliActivity.this, "OTP TERVERIVIKASI", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(RegisterPembeliActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            // when we receive the OTP it
            // contains a unique id which
            // we are storing in our string
            // which we have already created.
            verificationId = s;
        }
        @Override
        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
            final String code = phoneAuthCredential.getSmsCode();
            if (code != null){
                etOtp.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            Toast.makeText(RegisterPembeliActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };
    public static boolean isValidPassword(final String password){
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!]).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }
    public void load(){
        etUsername = findViewById(R.id.etUsername);
        etNamaPengguna = findViewById(R.id.etNamaPengguna);
        etPassword = findViewById(R.id.etPassword);
        etKonfirmasi = findViewById(R.id.etKonfirmasi);
        etNotelp = findViewById(R.id.etNotelp);
        etOtp = findViewById(R.id.etOTP);
        queue = Volley.newRequestQueue(getApplicationContext());
        btnRegister = findViewById(R.id.btnRegisterPembeli);
        btnOTP = findViewById(R.id.btnOTP);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
    }
    public void register(String username, String namaPengguna, String noTelp, String password){
        RegisterPembeliReq modal = new RegisterPembeliReq(username, namaPengguna, noTelp, password);
        Call<RegisterPembeliReq> call = apiInterface.RegisterPembeli(modal);
        call.enqueue(new Callback<RegisterPembeliReq>() {
            @Override
            public void onResponse(Call<RegisterPembeliReq> call, Response<RegisterPembeliReq> response) {
                if (response.isSuccessful()){
                    Toast.makeText(RegisterPembeliActivity.this, "Register Berhasil", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterPembeliActivity.this, LoginPembeliActivity.class);
                    startActivity(intent);

                }else{
                    try {
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        JSONArray username = jObjError.getJSONArray("username");
                        etUsername.setError(username.getString(0));
                        etUsername.requestFocus();

                    } catch (Exception e) {
//                        Toast.makeText(RegisterPembeliActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        Log.e("objectKu", e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<RegisterPembeliReq> call, Throwable t) {
                Log.e("Error found is : ",t.getMessage());
            }
        });
    }
    private void verifyGoogleReCAPTCHA() {

        // below line is use for getting our safety
        // net client and verify with reCAPTCHA
        SafetyNet.getClient(this).verifyWithRecaptcha(SITE_KEY)
                // after getting our client we have
                // to add on success listener.
                .addOnSuccessListener(this, new OnSuccessListener<SafetyNetApi.RecaptchaTokenResponse>() {
                    @Override
                    public void onSuccess(SafetyNetApi.RecaptchaTokenResponse response) {
                        // in below line we are checking the response token.
                        if (!response.getTokenResult().isEmpty()) {
                            // if the response token is not empty then we
                            // are calling our verification method.
                            handleVerification(response.getTokenResult());
                        }
                    }
                })
                .addOnFailureListener(this, new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // this method is called when we get any error.
                        if (e instanceof ApiException) {
                            ApiException apiException = (ApiException) e;
                            // below line is use to display an error message which we get.
                            Log.d("TAG", "Error message: " +
                                    CommonStatusCodes.getStatusCodeString(apiException.getStatusCode()));
                        } else {
                            // below line is use to display a toast message for any error.

                            Toast.makeText(RegisterPembeliActivity.this, "Error found is : " + e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    protected void handleVerification(final String responseToken) {
        // inside handle verification method we are
        // verifying our user with response token.
        // url to sen our site key and secret key
        // to below url using POST method.
        String url = "https://www.google.com/recaptcha/api/siteverify";

        // in this we are making a string request and
        // using a post method to pass the data.
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // inside on response method we are checking if the
                        // response is successful or not.
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("success")) {
                                Toast.makeText(RegisterPembeliActivity.this, "Berhasil!!", Toast.LENGTH_SHORT).show();
                                register(etUsername.getText().toString(), etNamaPengguna.getText().toString(),etNotelp.getText().toString(),etPassword.getText().toString());
                            } else {
                                // if the response if failure we are displaying
                                // a below toast message.
                                Toast.makeText(getApplicationContext(), String.valueOf(jsonObject.getString("error-codes")), Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception ex) {
                            // if we get any exception then we are
                            // displaying an error message in logcat.
                            Log.d("TAG", "JSON exception: " + ex.getMessage());
                        }
                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // inside error response we are displaying
                        // a log message in our logcat.
                        Log.d("TAG", "Error message: " + error.getMessage());
                    }
                }) {
            // below is the getParamns method in which we will
            // be passing our response token and secret key to the above url.
            @Override
            protected Map<String, String> getParams() {
                // we are passing data using hashmap
                // key and value pair.
                Map<String, String> params = new HashMap<>();
                params.put("secret", SECRET_KEY);
                params.put("response", responseToken);
                return params;
            }
        };
        // below line of code is use to set retry
        // policy if the api fails in one try.
        request.setRetryPolicy(new DefaultRetryPolicy(
                // we are setting time for retry is 5 seconds.
                50000,

                // below line is to perform maximum retries.
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        // at last we are adding our request to queue.
        queue.add(request);
    }
}