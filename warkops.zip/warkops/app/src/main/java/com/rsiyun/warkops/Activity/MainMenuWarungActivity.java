package com.rsiyun.warkops.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.rsiyun.warkops.Fragment.MenuFragment;
import com.rsiyun.warkops.Fragment.PesananWarkopFragment;
import com.rsiyun.warkops.Fragment.ProfileWarungFragment;
import com.rsiyun.warkops.R;

public class MainMenuWarungActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu_warung);
        getSupportActionBar().hide();
        load();
    }
    public void load(){
        BottomNavigationView navigationView = findViewById(R.id.bottomNavigationWarkop);
        navigationView.setOnNavigationItemSelectedListener(this);
        loadFragment(new MenuFragment());
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.fr_menu:
                fragment = new MenuFragment();
                break;
            case R.id.fr_pesanan_Warung:
                fragment = new PesananWarkopFragment();
                break;
            case R.id.fr_warung:
                fragment = new ProfileWarungFragment();
        }
        return loadFragment(fragment);
    }
    public boolean loadFragment(Fragment fragment){
        if (fragment!=null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container_warung,fragment).commit();
            return true;
        }
        return false;
    }
}