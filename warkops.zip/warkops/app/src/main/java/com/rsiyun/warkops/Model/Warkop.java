package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Warkop {
    @SerializedName("idwarkop")
    @Expose
    private String idwarkop;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("namapengguna")
    @Expose
    private String namapengguna;
    @SerializedName("namawarung")
    @Expose
    private String namawarung;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("password")
    @Expose
    private String password;
    @SerializedName("longtitude")
    @Expose
    private String longtitude;
    @SerializedName("latitude")
    @Expose
    private String latitude;
    @SerializedName("alamat")
    @Expose
    private String alamat;
    @SerializedName("notelp")
    @Expose
    private String notelp;
    @SerializedName("imgwarkop")
    @Expose
    private String imgwarkop;
    @SerializedName("rating")
    @Expose
    private Double rating;
    @SerializedName("action")
    @Expose
    private Integer action;
    @SerializedName("api_token")
    @Expose
    private String apiToken;

    public Warkop(String idwarkop, String username, String namapengguna, String namawarung, String email, String password, String longtitude, String latitude, String alamat, String notelp, String imgwarkop, Double rating, Integer action, String apiToken) {
        this.idwarkop = idwarkop;
        this.username = username;
        this.namapengguna = namapengguna;
        this.namawarung = namawarung;
        this.email = email;
        this.password = password;
        this.longtitude = longtitude;
        this.latitude = latitude;
        this.alamat = alamat;
        this.notelp = notelp;
        this.imgwarkop = imgwarkop;
        this.rating = rating;
        this.action = action;
        this.apiToken = apiToken;
    }

    public String getIdwarkop() {
        return idwarkop;
    }

    public void setIdwarkop(String idwarkop) {
        this.idwarkop = idwarkop;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamapengguna() {
        return namapengguna;
    }

    public void setNamapengguna(String namapengguna) {
        this.namapengguna = namapengguna;
    }

    public String getNamawarung() {
        return namawarung;
    }

    public void setNamawarung(String namawarung) {
        this.namawarung = namawarung;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNotelp() {
        return notelp;
    }

    public void setNotelp(String notelp) {
        this.notelp = notelp;
    }

    public String getImgwarkop() {
        return imgwarkop;
    }

    public void setImgwarkop(String imgwarkop) {
        this.imgwarkop = imgwarkop;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Integer getAction() {
        return action;
    }

    public void setAction(Integer action) {
        this.action = action;
    }

    public String getApiToken() {
        return apiToken;
    }

    public void setApiToken(String apiToken) {
        this.apiToken = apiToken;
    }
}
