package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.rsiyun.warkops.Adapter.KategoriMenuAdapter;
import com.rsiyun.warkops.Get.GetKategoriMenu;
import com.rsiyun.warkops.Model.KategoriMenu;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KategoriMenuWarungActivity extends AppCompatActivity {
    Toolbar toolbar;
    LinearLayout btnTambahKategori;
    ApiInterface apiInterface;
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager layoutManager;
    Integer idWarkop;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String sessionW = "SessionW";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori_menu_warung);
        load();
        toolbar();
        Panggil();
        btnTambahKategori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TambahKategori();
            }
        });
    }
    public void load(){
        btnTambahKategori = findViewById(R.id.btnTambahKategori);
        recyclerView = findViewById(R.id.rcvKategori);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        idWarkop = pref.getInt("idwarkop",0);
    }
    public void Panggil(){
        Call<GetKategoriMenu> kategoriMenuCall = apiInterface.getKategoriOne(""+idWarkop);
        kategoriMenuCall.enqueue(new Callback<GetKategoriMenu>() {
            @Override
            public void onResponse(Call<GetKategoriMenu> call, Response<GetKategoriMenu> response) {
                List<KategoriMenu> kategoriMenuList = response.body().getKategoriMenuList();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(kategoriMenuList.size()));
                adapter = new KategoriMenuAdapter(KategoriMenuWarungActivity.this,kategoriMenuList);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<GetKategoriMenu> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
                Toast.makeText(KategoriMenuWarungActivity.this, "", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void TambahKategori(){
        Intent intent = new Intent(this, TambahKategoriActivity.class);
        startActivity(intent);
    }
    public void mainMenuActivity(){
        Intent intent = new Intent(this, MainMenuWarungActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_right);
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarKategoriMenu);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainMenuActivity();
            }
        });
    }
}