package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.rsiyun.warkops.Adapter.MenuAdapter;
import com.rsiyun.warkops.Adapter.MenuWarkopAdapter;
import com.rsiyun.warkops.Get.GetKategoriMenu;
import com.rsiyun.warkops.Get.GetMenu;
import com.rsiyun.warkops.Model.KategoriMenu;
import com.rsiyun.warkops.Model.Menu;
import com.rsiyun.warkops.Model.MenuWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuWarkopActivity extends AppCompatActivity {
    LinearLayout btnTamabah;
    Toolbar toolbar;
    RecyclerView recyclerView;
    MenuWarkopAdapter adapter;
    List<Menu> menuList;
    Spinner spKategoriMenu;
    ApiInterface apiInterface;
    Integer idWarkop;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    public static final String sessionW = "SessionW";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_warkop);
        toolbar();
        load();
        initspiner();
        isiData();
        btnTamabah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TambahMenu();
            }
        });
    }
    public void toolbar(){
        toolbar = findViewById(R.id.toolbarMenu);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainMenuActivity();
            }
        });
    }
    public void load(){
        btnTamabah = findViewById(R.id.btnTambahMenu);
        recyclerView = findViewById(R.id.rcvMenu);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        spKategoriMenu = findViewById(R.id.spKategoriMenu);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        pref = getSharedPreferences(sessionW, Context.MODE_PRIVATE);
        idWarkop = pref.getInt("idwarkop",0);
    }
    public void TambahMenu(){
        Intent intent = new Intent(this, TambahMenuActivity.class);
        startActivity(intent);
    }
    public void isiData(){
        Call<GetMenu> call = apiInterface.getMenu(""+idWarkop);
        call.enqueue(new Callback<GetMenu>() {
            @Override
            public void onResponse(Call<GetMenu> call, Response<GetMenu> response) {
                menuList = response.body().getMenuList();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(menuList.size()));
                adapter = new MenuWarkopAdapter(MenuWarkopActivity.this, menuList);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<GetMenu> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
//        adapter = new MenuWarkopAdapter(this, menuWarkopList);
//        recyclerView.setAdapter(adapter);
    }
    public void initspiner(){
        apiInterface.getKategoriOne(""+idWarkop).enqueue(new Callback<GetKategoriMenu>() {
            @Override
            public void onResponse(Call<GetKategoriMenu> call, Response<GetKategoriMenu> response) {
                if (response.isSuccessful()){
                    List<KategoriMenu> kategoriMenuList = response.body().getKategoriMenuList();
                    List<String> listSpinner = new ArrayList<>();
                    for (int i = 0; i<kategoriMenuList.size(); i++){
                        listSpinner.add(kategoriMenuList.get(i).getKategori());
                    }
                    listSpinner.add(0,"kategori");
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MenuWarkopActivity.this, android.R.layout.simple_spinner_item, listSpinner);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spKategoriMenu.setAdapter(adapter);
                }else{
                    Toast.makeText(MenuWarkopActivity.this, "Gagal", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetKategoriMenu> call, Throwable t) {
                Toast.makeText(MenuWarkopActivity.this, "Internet", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void mainMenuActivity(){
        Intent intent = new Intent(this, MainMenuWarungActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_right);
    }
}