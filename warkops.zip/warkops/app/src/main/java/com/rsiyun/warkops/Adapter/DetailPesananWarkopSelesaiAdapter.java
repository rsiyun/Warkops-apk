package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rsiyun.warkops.Model.DetailPesananWarkopSelesai;
import com.rsiyun.warkops.R;

import java.util.List;

public class DetailPesananWarkopSelesaiAdapter extends RecyclerView.Adapter<DetailPesananWarkopSelesaiAdapter.ViewHolder> {
    Context context;
    List<DetailPesananWarkopSelesai> detailSelesaiList;

    public DetailPesananWarkopSelesaiAdapter(Context context, List<DetailPesananWarkopSelesai> detailSelesaiList) {
        this.context = context;
        this.detailSelesaiList = detailSelesaiList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan_detail_warkop_selesai,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DetailPesananWarkopSelesai detailPesananWarkopSelesai = detailSelesaiList.get(position);
        holder.tvNamaMenu.setText(detailPesananWarkopSelesai.getNamaMenu());
        holder.tvJumlah.setText(detailPesananWarkopSelesai.getJumlah());
        holder.tvHarga.setText(detailPesananWarkopSelesai.getHarga());
    }

    @Override
    public int getItemCount() {
        return detailSelesaiList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaMenu, tvHarga, tvJumlah;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaMenu = itemView.findViewById(R.id.tvNamaMenuDetail);
            tvHarga = itemView.findViewById(R.id.tvHargaDetail);
            tvJumlah = itemView.findViewById(R.id.tvJumlahDetail);
        }
    }
}
