package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Menu {
    @SerializedName("idmenu")
    @Expose
    private Integer idmenu;
    @SerializedName("idkategori")
    @Expose
    private Integer idkategori;
    @SerializedName("menu")
    @Expose
    private String menu;
    @SerializedName("imgmenu")
    @Expose
    private String imgmenu;
    @SerializedName("harga")
    @Expose
    private String harga;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("deskripsi")
    private String deskripsi;

    public Menu(Integer idmenu, Integer idkategori, String menu, String imgmenu, String harga, Integer status, String deskripsi) {
        this.idmenu = idmenu;
        this.idkategori = idkategori;
        this.menu = menu;
        this.imgmenu = imgmenu;
        this.harga = harga;
        this.status = status;
        this.deskripsi = deskripsi;
    }

    public Integer getIdmenu() {
        return idmenu;
    }

    public void setIdmenu(Integer idmenu) {
        this.idmenu = idmenu;
    }

    public Integer getIdkategori() {
        return idkategori;
    }

    public void setIdkategori(Integer idkategori) {
        this.idkategori = idkategori;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getImgmenu() {
        return imgmenu;
    }

    public void setImgmenu(String imgmenu) {
        this.imgmenu = imgmenu;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
