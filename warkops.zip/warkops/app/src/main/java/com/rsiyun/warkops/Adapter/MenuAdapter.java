package com.rsiyun.warkops.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.rsiyun.warkops.Activity.CartPembeliActivity;
import com.rsiyun.warkops.Activity.LoginPembeliActivity;
import com.rsiyun.warkops.Activity.MenuWarkopActivity;
import com.rsiyun.warkops.Activity.WarkopActivity;
import com.rsiyun.warkops.Model.MenuWarkop;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Model.Menu;
import com.rsiyun.warkops.Rest.DbWarkop;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {
    private Context context;
    private List<Menu> menuList;
    private String sidWarkop, namaWarkop, Alamat;

    public MenuAdapter(Context context, List<Menu> menuList, String sidWarkop, String namaWarkop, String Alamat) {
        this.context = context;
        this.menuList = menuList;
        this.sidWarkop = sidWarkop;
        this.namaWarkop = namaWarkop;
        this.Alamat = Alamat;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Menu menu = menuList.get(position);
        holder.tvNamaMenu.setText(menu.getMenu());
        holder.tvHarga.setText(menu.getHarga());
        holder.tvDeskripsi.setText(menu.getDeskripsi());
        holder.tvTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.idpelanggan.equals(0)){
                    Intent intent = new Intent(context, LoginPembeliActivity.class);
                    context.startActivity(intent);
                }else{
                    Integer idwarkop =Integer.parseInt(sidWarkop);
                    boolean coba = holder.dbWarkop.checkId(idwarkop);
                    if (coba){
                        String sqlIdmenu = "SELECT * FROM cart WHERE idmenu = "+menu.getIdmenu()+"";
                        Cursor cursor = holder.dbWarkop.select(sqlIdmenu);
                        if (cursor.moveToNext()){
                            Integer jumlah = cursor.getInt(cursor.getColumnIndexOrThrow("jumlah"));
                            Integer idmenu = cursor.getInt(cursor.getColumnIndexOrThrow("idmenu"));
                            jumlah++;
                            ((WarkopActivity)context).UpdateCart(jumlah,idmenu);
                            Toast.makeText(context, "data berhasil update", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context, WarkopActivity.class);
                            intent.putExtra("idwarkop", sidWarkop);
                            intent.putExtra("namaWarkop", namaWarkop );
                            intent.putExtra("alamat", Alamat );
                            context.startActivity(intent);
                        }else {
                            String sql = "INSERT INTO cart (idpenjual,idpelanggan,idmenu,menu,gambarMenu,warkop,alamat,harga,jumlah) VALUES ("+idwarkop+","+holder.idpelanggan+","+menu.getIdmenu()+",'"+menu.getMenu()+"','"+menu.getImgmenu()+"','"+namaWarkop+"','"+Alamat+"',"+menu.getHarga()+","+1+")";
                            holder.dbWarkop.runSQL(sql);
                            Toast.makeText(context, "data masuk", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context, WarkopActivity.class);
                            intent.putExtra("idwarkop", sidWarkop);
                            intent.putExtra("namaWarkop", namaWarkop );
                            intent.putExtra("alamat", Alamat );
                            context.startActivity(intent);
                        }
                    }else{
                        new AlertDialog.Builder(context).setTitle(R.string.app_name)
                                .setIcon(R.mipmap.ic_launcher)
                                .setMessage("Anda Memilih warkop lain, Apakah anda yakin Pesanan Lama akan kami buang")
                                .setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String sql = "DELETE From cart";
                                        holder.dbWarkop.runSQL(sql);
                                        Intent intent = new Intent(context, WarkopActivity.class);
                                        intent.putExtra("idwarkop", sidWarkop);
                                        intent.putExtra("namaWarkop", namaWarkop );
                                        intent.putExtra("alamat", Alamat);
                                        context.startActivity(intent);
                                    }
                                }).setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                }).show();
                    }
                }
            }
        });
        Glide.with(context).load(""+menu.getImgmenu()).override(203,223).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                return false;
            }
        }).into(holder.ivGambar);
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView ivGambar;
        TextView tvNamaMenu, tvHarga, tvDeskripsi, tvTambah;
        SharedPreferences pref;
        public static final String session = "Session";
        Integer idpelanggan;
        DbWarkop dbWarkop;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            pref = context.getSharedPreferences(session, Context.MODE_PRIVATE);
            idpelanggan = pref.getInt("idPelanggan",0);
            dbWarkop = new DbWarkop(context);
            dbWarkop.buatTable();
            tvHarga = itemView.findViewById(R.id.tvHarga);
            ivGambar = itemView.findViewById(R.id.ivGambar);
            tvNamaMenu = itemView.findViewById(R.id.tvNamaMenu);
            tvDeskripsi = itemView.findViewById(R.id.tvDeskripsi);
            tvTambah = itemView.findViewById(R.id.tvTambahkan);
        }
    }
}
