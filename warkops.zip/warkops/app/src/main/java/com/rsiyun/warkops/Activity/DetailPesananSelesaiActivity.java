package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.rsiyun.warkops.Adapter.DetailPesananAdapter;
import com.rsiyun.warkops.Get.GetDetail;
import com.rsiyun.warkops.Model.DetailPesanan;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPesananSelesaiActivity extends AppCompatActivity {
    private Toolbar toolbarDetailPesanan;
    RecyclerView recyclerView;
    List<DetailPesanan> detailPesananList;
    DetailPesananAdapter adapter;
    TextView tvNamaWarkop, tvStatus, tvTgl, tvTotal, tvRating;
    String sNamaWarkop, sTgl, sNotelp, sTotal, sImgWarkop;
    Integer sIdorder, sStatus;
    Double sRating;
    CircleImageView imgWarkop;
    ApiInterface apiInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_pesanan_selesai);
        toolbar();
        load();
        getIntentku();
        setIntentText();
        isiData();
    }
    public void toolbar(){
        toolbarDetailPesanan = findViewById(R.id.toolbarDetailPesanan);
        setSupportActionBar(toolbarDetailPesanan);
        toolbarDetailPesanan.setNavigationIcon(R.drawable.ic_back);
        toolbarDetailPesanan.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void load(){
        recyclerView = findViewById(R.id.rcvDetailPesanan);
        tvNamaWarkop = findViewById(R.id.tvNamaWarkop);
        tvStatus = findViewById(R.id.tvStatus);
        tvTgl = findViewById(R.id.tvtgl);
        tvTotal = findViewById(R.id.tvTotal);
        tvRating = findViewById(R.id.tvRating);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        imgWarkop = findViewById(R.id.ivGambar);
    }
    public void getIntentku(){
        Intent intent = getIntent();
        sImgWarkop = intent.getStringExtra("imgwarkop");
        sNamaWarkop = intent.getStringExtra("namawarung");
        sTgl = intent.getStringExtra("tgl");
        sIdorder = intent.getIntExtra("idorder", 0);
        sStatus = intent.getIntExtra("status",0);
        sNotelp = intent.getStringExtra("notelp");
        sTotal = intent.getStringExtra("total");
        sRating = intent.getDoubleExtra("rating", 0);
    }
    public void setIntentText(){
        tvNamaWarkop.setText(sNamaWarkop);
        tvTgl.setText(sTgl);
        Glide.with(this).load(""+sImgWarkop).into(imgWarkop);
        if (sStatus.equals(1)) {
            tvStatus.setText("Pesanan Sedang disiapkan");
        }
        else if(sStatus.equals(2)){
            tvStatus.setText("pesan Sedang diantar");
        }else{
            tvStatus.setText("Selesai");
        }
        tvTotal.setText(sTotal);
        tvRating.setText(""+sRating);
    }
    public void isiData(){
        Call<GetDetail> getDetailCall = apiInterface.getDetail(""+sIdorder);
        getDetailCall.enqueue(new Callback<GetDetail>() {
            @Override
            public void onResponse(Call<GetDetail> call, Response<GetDetail> response) {
                detailPesananList = response.body().getDetailPesananList();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(detailPesananList.size()));;
                adapter = new DetailPesananAdapter(DetailPesananSelesaiActivity.this,detailPesananList);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<GetDetail> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }

    public void btnBeriRating(View view) {
        Intent intent = new Intent(this, RatingWarkopActivity.class);
        startActivity(intent);
    }
}