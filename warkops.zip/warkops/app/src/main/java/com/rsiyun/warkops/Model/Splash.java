package com.rsiyun.warkops.Model;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.rsiyun.warkops.Activity.LoginPembeliActivity;
import com.rsiyun.warkops.Activity.MainActivity;
import com.rsiyun.warkops.Activity.PemilihanLoginActivity;
import com.rsiyun.warkops.R;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        Handler h = new Handler();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Splash.this, MainActivity.class);
                startActivity(i);
            }
        }, 500);
    }
}