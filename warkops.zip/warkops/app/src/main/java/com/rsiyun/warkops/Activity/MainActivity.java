package com.rsiyun.warkops.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.rsiyun.warkops.Fragment.AkunFragment;
import com.rsiyun.warkops.Fragment.Home;
import com.rsiyun.warkops.Fragment.PesananFragment;
import com.rsiyun.warkops.R;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener  {
    Button btnSelesai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        load();
    }
    public void load(){
        BottomNavigationView navigationView = findViewById(R.id.bottomNavigationView);
        navigationView.setOnNavigationItemSelectedListener(this);
        btnSelesai = findViewById(R.id.btnSelesai);
        loadFragment(new Home());
        if (getIntent().hasExtra("Cart")){
            loadFragment(new PesananFragment());
        }
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.fr_home:
                fragment = new Home();
                break;
            case R.id.fr_pesanan:
                fragment = new PesananFragment();
                break;
            case R.id.fr_akun:
                fragment = new AkunFragment();
                break;
        }
        return loadFragment(fragment);
    }
    private boolean loadFragment(Fragment fragment){
        if (fragment!=null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,fragment).commit();
            return true;
        }
        return false;
    }
}