package com.rsiyun.warkops.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.rsiyun.warkops.Activity.DetailPesananWarkopActivity;
import com.rsiyun.warkops.Model.PesananWarkop;
import com.rsiyun.warkops.Model.PesananWarkopSelesai;
import com.rsiyun.warkops.R;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PesananWarkopAdapter extends RecyclerView.Adapter<PesananWarkopAdapter.ViewHolder> {
    Context context;
    List<PesananWarkop> pesananWarkopList;

    public PesananWarkopAdapter(Context context, List<PesananWarkop> pesananWarkopList) {
        this.context = context;
        this.pesananWarkopList = pesananWarkopList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pesanan_warkop,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PesananWarkop pesananWarkop = pesananWarkopList.get(position);
        holder.tvNamaPembeli.setText(pesananWarkop.getUsername());
        holder.tvJam.setText(pesananWarkop.getTglorder());
        Glide.with(context).load(""+pesananWarkop.getImgPelanggan()).into(holder.ivGambar);
        if (pesananWarkop.getStatus().equals(1)) {
            holder.tvStatus.setText("Pesanan Sedang disiapkan");
        }else if (pesananWarkop.getStatus().equals(2)){
            holder.tvStatus.setText("Pesanan Sedang diantar");
        }else{
            holder.itemView.setVisibility(View.INVISIBLE);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailPesananWarkopActivity.class);
                intent.putExtra("Username", pesananWarkopList.get(position).getUsername());
                intent.putExtra("alamat", pesananWarkopList.get(position).getAlamat());
                intent.putExtra("tanggal", pesananWarkopList.get(position).getTglorder());
                intent.putExtra("total", pesananWarkopList.get(position).getTotal());
                intent.putExtra("status", pesananWarkopList.get(position).getStatus());
                intent.putExtra("idorder", pesananWarkopList.get(position).getIdorder());
                intent.putExtra("noTelp", pesananWarkopList.get(position).getNotelp());
                intent.putExtra("imgPelanggan", pesananWarkopList.get(position).getImgPelanggan());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() { return pesananWarkopList.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvNamaPembeli, tvStatus,tvJam;
        CircleImageView ivGambar;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNamaPembeli = itemView.findViewById(R.id.tvNamaPembeli);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvJam = itemView.findViewById(R.id.tvJam);
            ivGambar = itemView.findViewById(R.id.ivGambar);
        }
    }
}
