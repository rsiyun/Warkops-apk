package com.rsiyun.warkops.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Pelanggan {
    @SerializedName("idpelanggan")
    @Expose
    private Integer idpelanggan;
    @SerializedName("username")
    @Expose
    private String username;
    @SerializedName("namapengguna")
    @Expose
    private String namapengguna;
    @SerializedName("notelp")
    @Expose
    private String notelp;
    @SerializedName("imgpelanggan")
    @Expose
    private String imgpelanggan;

    public Pelanggan(Integer idpelanggan, String username, String namapengguna, String notelp, String imgpelanggan) {
        this.idpelanggan = idpelanggan;
        this.username = username;
        this.namapengguna = namapengguna;
        this.notelp = notelp;
        this.imgpelanggan = imgpelanggan;
    }

    public Integer getIdpelanggan() {
        return idpelanggan;
    }

    public void setIdpelanggan(Integer idpelanggan) {
        this.idpelanggan = idpelanggan;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNamapengguna() {
        return namapengguna;
    }

    public void setNamapengguna(String namapengguna) {
        this.namapengguna = namapengguna;
    }

    public String getNotelp() {
        return notelp;
    }

    public void setNotelp(String notelp) {
        this.notelp = notelp;
    }

    public String getImgpelanggan() {
        return imgpelanggan;
    }

    public void setImgpelanggan(String imgpelanggan) {
        this.imgpelanggan = imgpelanggan;
    }
}
