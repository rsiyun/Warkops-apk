package com.rsiyun.warkops.Get;

import com.google.gson.annotations.SerializedName;
import com.rsiyun.warkops.Model.Menu;

import java.util.List;

public class GetMenu {
    @SerializedName("message")
    String message;
    @SerializedName("data")
    List<Menu> menuList;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Menu> getMenuList() {
        return menuList;
    }

    public void setMenuList(List<Menu> menuList) {
        this.menuList = menuList;
    }
}