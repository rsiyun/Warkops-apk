package com.rsiyun.warkops.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.rsiyun.warkops.Adapter.MenuAdapter;
import com.rsiyun.warkops.Get.GetKategoriMenu;
import com.rsiyun.warkops.Get.GetMenu;
import com.rsiyun.warkops.Model.KategoriMenu;
import com.rsiyun.warkops.Model.Menu;
import com.rsiyun.warkops.R;
import com.rsiyun.warkops.Rest.ApiClient;
import com.rsiyun.warkops.Rest.ApiInterface;
import com.rsiyun.warkops.Rest.DbWarkop;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WarkopActivity extends AppCompatActivity {
    CollapsingToolbarLayout collapsingToolbar;
    private Toolbar toolbarWarkop;
    DbWarkop dbWarkop;
    Spinner spKategori;
    RecyclerView rcvMenu;
    MenuAdapter adapter;
    List<Menu> menuList;
    ImageView imgInfo;
    LinearLayout tombolCart;
    ApiInterface apiInterface;
    String sIdWarkop, NamaWarkop, Alamat;
    double sum;
    TextView tvTambah, tvJumlahItem, tvAlamatWarkop, tvTotal;



    public void onBackPressed() {

        // Put your own code here which you want to run on back button click.

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

//        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warkop);
        load();
        initspiner();
        isiData();
        // Collapsing toolbar dan tombol kembali
        toolbarWarkop = (Toolbar) findViewById(R.id.toolbarWarkop);
        setSupportActionBar(toolbarWarkop);
        toolbarWarkop.setNavigationIcon(R.drawable.ic_back);
        toolbarWarkop.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        // end collapsing toolbar dan tombol kembali
        // pick put extra
        if (getIntent().hasExtra("namaWarkop")){
            NamaWarkop = getIntent().getStringExtra("namaWarkop");
            Alamat = getIntent().getStringExtra("alamat");
            collapsingToolbar.setTitle(NamaWarkop);
        }

        // end pic put extra
        imgInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WarkopActivity.this, InfoWarkopActivity.class);
                startActivity(intent);
            }
        });
        tombolCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WarkopActivity.this, CartPembeliActivity.class);
                intent.putExtra("Total", sum);
                intent.putExtra("idwarkop",sIdWarkop);
                intent.putExtra("namaWarkop", NamaWarkop);
                intent.putExtra("alamat", Alamat);
                startActivity(intent);
            }
        });
        String sql = "SELECT * FROM cart";
        Cursor cursor = dbWarkop.select(sql);
        if (cursor.getCount() == 0){
            tombolCart.setVisibility(View.GONE);
        }else {
            btnCart();
            tombolCart.setVisibility(View.VISIBLE);
        }
    }
    public void isiData(){
        Call<GetMenu> menuCall = apiInterface.getMenu(sIdWarkop);
        menuCall.enqueue(new Callback<GetMenu>() {
            @Override
            public void onResponse(Call<GetMenu> call, Response<GetMenu> response) {
                menuList = response.body().getMenuList();
                Log.d("Retrofit Get", "Jumlah data Kontak: " +
                        String.valueOf(menuList.size()));
                adapter = new MenuAdapter(WarkopActivity.this, menuList, sIdWarkop, NamaWarkop, Alamat);
                adapter.notifyDataSetChanged();
                rcvMenu.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<GetMenu> call, Throwable t) {
                Log.e("Retrofit Get", t.toString());
            }
        });
    }
    public void initspiner(){
        apiInterface.getKategoriOne(sIdWarkop).enqueue(new Callback<GetKategoriMenu>() {
            @Override
            public void onResponse(Call<GetKategoriMenu> call, Response<GetKategoriMenu> response) {
                if (response.isSuccessful()){
                    List<KategoriMenu> kategoriMenuList = response.body().getKategoriMenuList();
                    List<String> listSpinner = new ArrayList<String>();
                    for (int i = 0; i < kategoriMenuList.size(); i++){
                        listSpinner.add(kategoriMenuList.get(i).getKategori());
                    }
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(WarkopActivity.this, android.R.layout.simple_spinner_item, listSpinner);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spKategori.setAdapter(adapter);
                }else {
                    Toast.makeText(WarkopActivity.this, "gagal", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetKategoriMenu> call, Throwable t) {
                Toast.makeText(WarkopActivity.this, "Internet", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void load(){
        Intent intent = getIntent();
        dbWarkop = new DbWarkop(this);
        dbWarkop.buatTable();
        imgInfo = findViewById(R.id.imgInfo);
        rcvMenu = findViewById(R.id.rcvMenu);
        tombolCart = findViewById(R.id.tombolCart);
        tvAlamatWarkop = findViewById(R.id.tvAlamatWarkop);
        tvTotal = findViewById(R.id.tvTotalan);
        tvJumlahItem = findViewById(R.id.tvJumlahItem);
        rcvMenu.setLayoutManager(new LinearLayoutManager(this));
        spKategori = findViewById(R.id.spKategori);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Typeface typeface = ResourcesCompat.getFont(this,R.font.kanit_medium);
         collapsingToolbar = findViewById(R.id.collapsing_toolbar);
        collapsingToolbar.setCollapsedTitleTypeface(typeface);
        collapsingToolbar.setExpandedTitleTypeface(typeface);
        sIdWarkop = intent.getStringExtra("idwarkop");
    }

    public void btnCart() {
        String sql = "SELECT warkop,alamat,harga,jumlah FROM cart";
        Cursor cursor = dbWarkop.select(sql);
        int jumlahItem = cursor.getCount();
        tvJumlahItem.setText(""+jumlahItem+" Item");
        ArrayList<String> iconList = new ArrayList<>();
        ArrayList<String> listaja = new ArrayList<>();
        if (cursor.moveToFirst()){
            do {
                String warkop = cursor.getString(0);
                String alamat = cursor.getString(1);
                Float harga = cursor.getFloat(2);
                Integer jumlah = cursor.getInt(3);
                Float total = harga*jumlah;
                iconList.add(""+total);
                listaja.add(warkop);
                listaja.add(alamat);
            }while (cursor.moveToNext());
        }
//        Float total= Float.parseFloat(iconList.get(0)) + Float.parseFloat(iconList.get(1));
        sum = 0;
        for (int i=0; i<iconList.size(); i++){
            String newStuff = iconList.get(i);
            sum = sum + Float.parseFloat(newStuff);
        }
        tvTotal.setText("Rp."+sum);
        tvAlamatWarkop.setText(listaja.get(0)+", "+listaja.get(listaja.size()-1));
        cursor.close();

    }
    public void UpdateCart(Integer jumlah, Integer idmenu){
        String sql = "UPDATE cart SET jumlah = "+jumlah+" WHERE idmenu = "+idmenu+"";
        dbWarkop.runSQL(sql);
    }
    
}