package com.rsiyun.warkops.Rest;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.rsiyun.warkops.Activity.WarkopActivity;

public class DbWarkop extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="dbwarkop";
    private static final int VERSION=1;
    SQLiteDatabase db;

    public DbWarkop(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        db = this.getWritableDatabase();
    }
   public boolean runSQL(String sql){
        try {
            db.execSQL(sql);
            return true;
        }catch (Exception e){
            return false;
        }
    }
    public void buatTable(){
        String tblCart= "CREATE TABLE \"cart\" (\n" +
                "\t\"idcart\"\tINTEGER,\n" +
                "\t\"idpenjual\"\tINTEGER,\n" +
                "\t\"idpelanggan\"\tINTEGER,\n" +
                "\t\"idmenu\"\tINTEGER,\n" +
                "\t\"menu\"\tTEXT,\n" +
                "\t\"gambarMenu\"\tTEXT,\n" +
                "\t\"warkop\"\tTEXT,\n" +
                "\t\"alamat\"\tTEXT,\n" +
                "\t\"harga\"\tREAL,\n" +
                "\t\"jumlah\"\tINTEGER,\n" +
                "\tPRIMARY KEY(\"idcart\" AUTOINCREMENT)\n" +
                ");";
        runSQL(tblCart);

    }
    public boolean checkId(Integer idpenjual){
        String Query = "SELECT idpenjual FROM cart ORDER BY idcart ASC LIMIT 1";
        Cursor cursor = db.rawQuery(Query , null);
        if (cursor.getCount() == 0){
            return true;
        }else{
            if (cursor.moveToFirst()){
                String[] arrData = new String[cursor.getColumnCount()];
                arrData[0] = cursor.getString(0);
                Integer idpenjualDb = Integer.parseInt(arrData[0]);
                if (idpenjualDb.equals(idpenjual)){
                    return true;
                }else{
                    return false;
                }
            }
            return false;
        }
    }
    public Cursor select(String sql){
        try {
            return db.rawQuery(sql, null);
        }catch (Exception e){
            return null;
        }
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
